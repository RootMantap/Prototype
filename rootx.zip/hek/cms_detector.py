#!/usr/bin/env python3
"""
CMS DETECTOR MODULE v1.0
========================
Deteksi CMS (WordPress, Joomla, Drupal, OpenCart, dll) dari target
Diadaptasi dari AlienExploit Tool4
Diintegrasikan ke GROOTX Exploitation Suite
"""

import requests
import re
import json
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
}

# CMS signatures — Accurate detection with version extraction
CMS_SIGNATURES = {
    'WordPress': {
        'meta': ['WordPress', 'wp-content', 'wp-includes'],
        'paths': ['/wp-login.php', '/wp-admin/', '/wp-content/', '/wp-includes/', '/wp-json/', '/xmlrpc.php'],
        'headers': ['X-Powered-By: WP'],
        'version_pattern': r'WordPress\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 1,
    },
    'Joomla': {
        'meta': ['Joomla', 'com_content', 'com_users'],
        'paths': ['/administrator/', '/components/com_content/', '/media/jui/', '/index.php?option=com_'],
        'headers': ['X-Content-Encoded-By: Joomla'],
        'version_pattern': r'Joomla!\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 2,
    },
    'Drupal': {
        'meta': ['Drupal', 'drupal', 'sites/default'],
        'paths': ['/user/login', '/core/', '/sites/default/files/', '/update.php', '/cron.php'],
        'headers': ['X-Generator: Drupal'],
        'version_pattern': r'Drupal\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 3,
    },
    'OpenCart': {
        'meta': ['OpenCart', 'catalog/controller', 'route=common/login'],
        'paths': ['/admin/index.php?route=common/login', '/catalog/'],
        'headers': [],
        'version_pattern': r'OpenCart\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 4,
    },
    'Laravel': {
        'meta': ['Laravel', 'laravel_session'],
        'paths': ['/api/', '/vendor/', '/artisan', '/server.php'],
        'headers': ['Set-Cookie: laravel_session'],
        'version_pattern': r'Laravel\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 5,
    },
    'CodeIgniter': {
        'meta': ['CodeIgniter', 'ci_session'],
        'paths': ['/application/', '/system/', '/user_guide/'],
        'headers': ['Set-Cookie: ci_session'],
        'version_pattern': r'CodeIgniter\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 6,
    },
    'phpMyAdmin': {
        'meta': ['phpMyAdmin', 'pma_logo'],
        'paths': ['/phpmyadmin/', '/pma/'],
        'headers': [],
        'version_pattern': r'phpMyAdmin\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 7,
    },
    'Magento': {
        'meta': ['Magento', 'Mage.Cookies'],
        'paths': ['/skin/frontend/', '/app/etc/'],
        'headers': ['X-Magento-Cache-Debug'],
        'version_pattern': r'Magento\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 8,
    },
    'PrestaShop': {
        'meta': ['PrestaShop', 'prestashop'],
        'paths': ['/modules/', '/themes/'],
        'headers': [],
        'version_pattern': r'PrestaShop\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 9,
    },
    'Shopify': {
        'meta': ['Shopify', 'cdn.shopify.com'],
        'paths': ['/cart.js', '/products/'],
        'headers': ['X-Shopify-Stage'],
        'version_pattern': None,
        'priority': 10,
    },
    'vBulletin': {
        'meta': ['vBulletin', 'vbulletin'],
        'paths': ['/forum/', '/forums/', '/ajax/render/widget_php'],
        'headers': [],
        'version_pattern': r'vBulletin\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 11,
    },
    'phpBB': {
        'meta': ['phpBB', 'phpbb'],
        'paths': ['/forum/', '/viewforum.php'],
        'headers': [],
        'version_pattern': r'phpBB\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 12,
    },
    'SMF': {
        'meta': ['SMF', 'simplemachines'],
        'paths': ['/forum/', '/index.php'],
        'headers': [],
        'version_pattern': r'SMF\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 13,
    },
    'WooCommerce': {
        'meta': ['WooCommerce', 'woocommerce'],
        'paths': ['/wp-content/plugins/woocommerce/', '/shop/'],
        'headers': [],
        'version_pattern': r'WooCommerce\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 14,
    },
    'bbPress': {
        'meta': ['bbPress', 'bbpress'],
        'paths': ['/forums/', '/wp-content/plugins/bbpress/'],
        'headers': [],
        'version_pattern': r'bbPress\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 15,
    },
    'BuddyPress': {
        'meta': ['BuddyPress', 'buddypress'],
        'paths': ['/members/', '/wp-content/plugins/buddypress/'],
        'headers': [],
        'version_pattern': r'BuddyPress\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 16,
    },
    'MediaWiki': {
        'meta': ['MediaWiki', 'mediawiki'],
        'paths': ['/wiki/', '/index.php?title=', '/api.php', '/load.php'],
        'headers': ['X-Content-Encoded-By: MediaWiki'],
        'version_pattern': r'MediaWiki\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 17,
    },
    'Roundcube': {
        'meta': ['Roundcube', 'roundcube'],
        'paths': ['/roundcube/', '/webmail/', '/rc/'],
        'headers': [],
        'version_pattern': r'Roundcube\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 18,
    },
    'phpFM': {
        'meta': ['phpFM', 'PHP File Manager', 'file manager'],
        'paths': ['/phpfm/', '/fileman/', '/fm/'],
        'headers': [],
        'version_pattern': r'phpFM\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 19,
    },
    'SmarterMail': {
        'meta': ['SmarterMail', 'smartermail'],
        'paths': ['/smartermail/', '/mail/', '/webmail/', '/interface/'],
        'headers': [],
        'version_pattern': r'SmarterMail\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 20,
    },
    'PeopleSoft': {
        'meta': ['PeopleSoft', 'peoplesoft'],
        'paths': ['/PSEMHUB/', '/PSIGW/', '/psp/'],
        'headers': [],
        'version_pattern': r'PeopleSoft\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 21,
    },
    'DouPHP': {
        'meta': ['DouPHP', 'Powered by DouPHP'],
        'paths': ['/admin/', '/include/', '/cache/', '/data/'],
        'headers': [],
        'version_pattern': r'DouPHP\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 22,
    },
    'PHPUnit': {
        'meta': ['PHPUnit', 'phpunit'],
        'paths': ['/vendor/phpunit/', '/phpunit/'],
        'headers': [],
        'version_pattern': r'PHPUnit\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 23,
    },
    'Revslider': {
        'meta': ['revslider', 'Revslider'],
        'paths': ['/wp-content/plugins/revslider/'],
        'headers': [],
        'version_pattern': r'revslider\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 24,
    },
    'SocialWarfare': {
        'meta': ['social-warfare', 'Social Warfare'],
        'paths': ['/wp-content/plugins/social-warfare/'],
        'headers': [],
        'version_pattern': r'Social\s*Warfare\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 25,
    },
    'FCKEditor': {
        'meta': ['FCKeditor', 'fckeditor'],
        'paths': ['/fckeditor/', '/editor/'],
        'headers': [],
        'version_pattern': r'FCKeditor\s*(\d+\.\d+(?:\.\d+)?)?',
        'priority': 26,
    },
}


class CMSDetector:
    """Deteksi CMS dari target."""
    
    def __init__(self):
        self.results = {}
    
    def detect(self, target):
        """Deteksi CMS dari single target dengan akurasi tinggi."""
        target = target.strip().rstrip('/')
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target
        
        detected = []
        scores = {}
        versions = {}
        methods = {}
        
        # Method 1: Fetch homepage dan cek meta generator + content
        try:
            r = requests.get(target, timeout=8, headers=HEADERS, verify=False, allow_redirects=True)
            html = r.text
            headers_dict = dict(r.headers)
            
            for cms, sig in CMS_SIGNATURES.items():
                score = 0
                method = []
                
                # Check meta generator (paling akurate)
                if sig.get('version_pattern'):
                    match = re.search(sig['version_pattern'], html, re.I)
                    if match:
                        score += 10
                        method.append('meta_generator')
                        if match.lastindex and match.group(1):
                            versions[cms] = match.group(1)
                
                # Check content patterns
                for meta in sig['meta']:
                    if meta.lower() in html.lower():
                        score += 2
                        method.append('content')
                        break
                
                # Check headers
                for header in sig['headers']:
                    if header.lower() in str(headers_dict).lower():
                        score += 3
                        method.append('header')
                        break
                
                if score > 0:
                    scores[cms] = score
                    methods[cms] = method
        except:
            pass
        
        # Method 2: Path-based detection (kalau homepage tidak conclusive)
        if not scores or max(scores.values()) < 5:
            for cms, sig in sorted(CMS_SIGNATURES.items(), key=lambda x: x[1].get('priority', 99)):
                for path in sig['paths']:
                    try:
                        r = requests.get(f'{target}{path}', timeout=5, headers=HEADERS, verify=False, allow_redirects=True)
                        if r.status_code in (200, 301, 302, 403):
                            score = 3
                            # Check content untuk konfirmasi
                            for meta in sig['meta']:
                                if meta.lower() in r.text.lower():
                                    score += 2
                                    break
                            if cms not in scores or scores[cms] < score:
                                scores[cms] = score
                                methods[cms] = ['path']
                            break  # Satu path cukup untuk CMS ini
                    except:
                        continue
        
        # Sort by score
        sorted_cms = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        
        if sorted_cms:
            detected = [cms for cms, score in sorted_cms if score >= 3]
        
        primary = detected[0] if detected else 'Unknown'
        
        return {
            'target': target,
            'detected': detected,
            'scores': scores,
            'primary': primary,
            'version': versions.get(primary, ''),
            'methods': methods.get(primary, []),
        }
    
    def detect_mass(self, targets, threads=50):
        """Deteksi CMS dari multiple targets."""
        console.print(f"\n[bold cyan]MASS CMS DETECTION[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Detecting CMS...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.detect, t): t for t in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        result = future.result()
                        results.append(result)
                        if result['detected']:
                            console.print(f"  [green]{result['target']}: {', '.join(result['detected'])}[/green]")
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]DETECTION COMPLETE[/bold green]")
        
        cms_counts = {}
        for r in results:
            for cms in r['detected']:
                cms_counts[cms] = cms_counts.get(cms, 0) + 1
        
        if cms_counts:
            table = Table(title="CMS Detection Summary")
            table.add_column("CMS", width=20)
            table.add_column("Count", justify="right", width=10)
            for cms, count in sorted(cms_counts.items(), key=lambda x: x[1], reverse=True):
                table.add_row(cms, str(count))
            console.print(table)
        
        return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="CMS Detector")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--threads", type=int, default=50)
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    detector = CMSDetector()
    detector.detect_mass(targets, args.threads)


if __name__ == "__main__":
    main()
