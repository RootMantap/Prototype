# CVE Reference - GROOTX v3.0
# CVE exploits yang tersedia di tools

## CVE-2018-7600 - Drupalgeddon2
- Endpoint: /user/password, /sites/default/files/, /user/login
- CMS: Drupal 7.x, 8.x
- Type: RCE

## CVE-2017-9841 - PHPUnit RCE
- Endpoint: /vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php
- CMS: Laravel, Symfony (dengan PHPUnit)
- Type: RCE

## CVE-2019-9978 - Social Warfare RCE
- Endpoint: /wp-admin/admin-post.php?swp_debug=load_options
- CMS: WordPress (Social Warfare plugin < 3.5.3)
- Type: RCE

## CVE-2014-9735 - Revslider Shell Upload
- Endpoint: /wp-admin/admin-ajax.php?action=revslider_ajax_action
- CMS: WordPress (Revslider plugin)
- Type: Shell Upload

## CVE-2019-6340 - Drupal 8 RESTful RCE
- Endpoint: /node/?_format=hal_json, /rest/
- CMS: Drupal 8.x
- Type: RCE

## CVE-2019-16759 - vBulletin RCE
- Endpoint: /ajax/render/widget_php
- CMS: vBulletin 5.x
- Type: RCE

## CVE-2015-8562 - Joomla RCE
- Endpoint: /administrator/, /components/
- CMS: Joomla 1.5-3.4.5
- Type: RCE

## CVE-2016-9838 - Joomla Take Admin
- Endpoint: /language/en-GB/en-GB.xml
- CMS: Joomla
- Type: Privilege Escalation

## CVE-2017-16562 - UserPro RCE
- Endpoint: /?up_auto_log=true, /wp-content/plugins/userpro/
- CMS: WordPress (UserPro plugin)
- Type: RCE

## CVE-2018-19207 - WP GDPR Compliance RCE
- Endpoint: /wp-json/wp-gdpr-compliance/v1/data/request
- CMS: WordPress (WP GDPR Compliance plugin)
- Type: RCE

## CVE-2019-15866 - Crelly Slider RCE
- Endpoint: /wp-admin/admin-ajax.php?action=crelly_slider_upload
- CMS: WordPress (Crelly Slider plugin)
- Type: RCE

## CVE-2019-9879 - WP GraphQL RCE
- Endpoint: /wp-json/graphql
- CMS: WordPress (WP GraphQL plugin)
- Type: RCE

## CVE-2014-4725 - Wysija Newsletters RCE
- Endpoint: /wp-admin/admin-post.php?page=wysija_campaigns&action=themes
- CMS: WordPress (Wysija Newsletters plugin)
- Type: RCE

## CVE-2015-4455 - Gravity Forms RCE
- Endpoint: /?gf_page=upload
- CMS: WordPress (Gravity Forms plugin)
- Type: RCE

## CVE-2015-1579 - Revslider Config
- Endpoint: /wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css
- CMS: WordPress (Revslider plugin)
- Type: Information Disclosure

## CVE-2015-5151 - Revslider CSS
- Endpoint: /wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css
- CMS: WordPress (Revslider plugin)
- Type: Information Disclosure

## CVE-2006-2529 - FCKEditor RCE
- Endpoint: /fckeditor/editor/filemanager/upload/php/upload.php
- CMS: FCKEditor
- Type: RCE

## CVE-2008-3362 - Download Manager RCE
- Endpoint: /wp-content/plugins/downloads-manager/upload/
- CMS: WordPress (Download Manager plugin)
- Type: RCE

## CVE-2014-3704 - Drupal Add Admin
- Endpoint: /user/register, /?q=user/register
- CMS: Drupal 7.x
- Type: Privilege Escalation
